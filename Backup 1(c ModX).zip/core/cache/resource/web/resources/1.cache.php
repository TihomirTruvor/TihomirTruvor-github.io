<?php  return array (
  'resourceClass' => 'modDocument',
  'resource' => 
  array (
    'id' => 1,
    'type' => 'document',
    'contentType' => 'text/html',
    'pagetitle' => 'Home Greennovo',
    'longtitle' => 'Home Greennovo',
    'description' => 'Houhua (Tianjin) Motive Power Technology Co., Ltd.',
    'alias' => 'index',
    'alias_visible' => 1,
    'link_attributes' => '',
    'published' => 1,
    'pub_date' => 0,
    'unpub_date' => 0,
    'parent' => 0,
    'isfolder' => 0,
    'introtext' => '',
    'content' => '',
    'richtext' => 1,
    'template' => 1,
    'menuindex' => 0,
    'searchable' => 1,
    'cacheable' => 1,
    'createdby' => 1,
    'createdon' => 1637069857,
    'editedby' => 1,
    'editedon' => 1640680528,
    'deleted' => 0,
    'deletedon' => 0,
    'deletedby' => 0,
    'publishedon' => 0,
    'publishedby' => 0,
    'menutitle' => '',
    'donthit' => 0,
    'privateweb' => 0,
    'privatemgr' => 0,
    'content_dispo' => 0,
    'hidemenu' => 1,
    'class_key' => 'modDocument',
    'context_key' => 'web',
    'content_type' => 1,
    'uri' => 'index.html',
    'uri_override' => 0,
    'hide_children_in_tree' => 0,
    'show_in_tree' => 1,
    'properties' => NULL,
    'image_support' => 
    array (
      0 => 'image_support',
      1 => 'assets/img/home/support.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'image_product' => 
    array (
      0 => 'image_product',
      1 => 'assets/img/home/pr-center.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'mobile_image_product' => 
    array (
      0 => 'mobile_image_product',
      1 => 'assets/img/home/mob-pr-center.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'image_innovation' => 
    array (
      0 => 'image_innovation',
      1 => 'assets/img/home/innovation.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'mobile_image_innovation' => 
    array (
      0 => 'mobile_image_innovation',
      1 => 'assets/img/home/mob-innovation.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'image_about_gteennovo' => 
    array (
      0 => 'image_about_gteennovo',
      1 => 'assets/img/home/about-greennovo.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'mobile_image_about_gteennovo' => 
    array (
      0 => 'mobile_image_about_gteennovo',
      1 => 'assets/img/home/mob-about-greennovo.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'about-title' => 
    array (
      0 => 'about-title',
      1 => 'Greennovo',
      2 => 'default',
      3 => NULL,
      4 => 'tag',
    ),
    'rd-innovation-title' => 
    array (
      0 => 'rd-innovation-title',
      1 => 'R&D INNOVATION',
      2 => 'default',
      3 => NULL,
      4 => 'tag',
    ),
    'support-title' => 
    array (
      0 => 'support-title',
      1 => 'Support&Service',
      2 => 'default',
      3 => NULL,
      4 => 'tag',
    ),
    'product-title' => 
    array (
      0 => 'product-title',
      1 => 'Product center',
      2 => 'default',
      3 => NULL,
      4 => 'tag',
    ),
    'image-slide1' => 
    array (
      0 => 'image-slide1',
      1 => 'assets/img/home/Slide1-opt.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'nav-contact' => 
    array (
      0 => 'nav-contact',
      1 => 'Contact Us',
      2 => 'default',
      3 => NULL,
      4 => 'tag',
    ),
    'mobile-image-slide1' => 
    array (
      0 => 'mobile-image-slide1',
      1 => 'assets/img/home/mobSlide1.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'text-slide1' => 
    array (
      0 => 'text-slide1',
      1 => 'R-series are in High Power, Low noise and High Efficiency. All with compact design to get higher Torque. Extremely Comfortable for cycling.',
      2 => 'default',
      3 => NULL,
      4 => 'text',
    ),
    'image-slide2' => 
    array (
      0 => 'image-slide2',
      1 => 'assets/img/home/Slide21.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'mobile-image-slide2' => 
    array (
      0 => 'mobile-image-slide2',
      1 => 'assets/img/home/mobSlide21.jpg',
      2 => 'default',
      3 => NULL,
      4 => 'image',
    ),
    'text-slide2' => 
    array (
      0 => 'text-slide2',
      1 => 'Big Torque, Noiseless and Strong Power are key characteristic for F-Series motors. FAT Greennovo motor is remarkable for its high efficiency with technical innovation.',
      2 => 'default',
      3 => NULL,
      4 => 'text',
    ),
    '_content' => '<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	
	<link type="image/x-icon" rel="shortcut icon" href="/assets/img/favicon_32.ico">
	<link type="image/png" sizes="16x16" rel="icon" href="/assets/img/favicon_16.png">
	<link type="image/png" sizes="32x32" rel="icon" href="/assets/img/favicon_32.png">
	<link type="image/png" sizes="96x96" rel="icon" href="/assets/img/favicon_96.png">
	<link type="image/png" sizes="120x120" rel="icon" href="/assets/img/favicon_120.png">

	<link rel="stylesheet" href="/assets/css/normalize.css">
	<link rel="stylesheet" href="/assets/css/style.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/><!--Свайпер-->

	<meta name="viewport" content="width=device-width">
	<meta name="description" content ="Houhua (Tianjin) Motive Power Technology Co., Ltd."/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<base href="[[!++site_url]]">

	<title>Home Greennovo</title>
</head>
<body>
<!-- Шапка сайта -->
	<header class="main-header">
		<div class="top-wrapper">
			<div class="container">
				<a class="header-logo" href="index.html"> <!-- Логотип сайта -->
	<img src="/assets/img/logo.gif" width="95" height="68" alt="logo greennovo">
</a>
				<nav class="navigation">
	<input id="menu__toggle" type="checkbox" /><!--Для мобильного меню-->
	<label class="menu__btn" for="menu__toggle"><!--Для мобильного меню-->
		<span></span>
	</label>
<!-- Вывод меню -->
<div class="container1">
    <div  class="nav-wrapper"><div class="nav-item"><a class="nav-button" href="about-greennovo.html">About Greennovo</a></div><div class="nav-item"><a class="nav-button" href="center/">Product center</a><ul class="sub-menu"><li><a href="greennovo-motor/">Greennovo Motor</a></li><li><a href="battery/">Battery</a></li><li><a href="display/">Display</a></li><li><a href="controller/">Controller</a></li></ul><div class="arrow-mini"></div></div><div class="nav-item"><a class="nav-button" href="innovation.html">R&D Innovation</a></div><div class="nav-item"><a class="nav-button" href="support-and-service.html">Support&Service</a></div></div>
    <div class="nav-item"><a class="nav-button" href="#contact">Contact Us</a></div>
</div>
	<!--
	&tplHere = `@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a></div>[[+wrapper]]` [[Для активного пункта меню]]
	<div class="container1">
	
	&tplParentRow = `@INLINE <div class="nav-item">
                                <a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]
                            </div>` [[Для родительского пункта меню]]
	    <div wra>
		<div class="nav-item">
			<a class="nav-button" href="#">About Greennovo</a>
		</div>
		<div class="nav-item">
			<a class="nav-button" href="#">Product Center</a>
			<ul class="sub-menu">
				<li><a href="#">Greennovo Motor</a></li>
				<li><a href="#">Battery</a></li>
				<li><a href="#">Display</a></li>
				<li><a href="#">Controller</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#">R&D Innovation</a>
			<ul class="sub-menu">
				<li><a href="#">Innovation Idea</a></li>
				<li><a href="#">Qualification Certificates</a></li>
				<li><a href="#">Test Laboratory</a></li>
				<li><a href="#">Manufacturing Base</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Support">Support&Service</a>
			<ul class="sub-menu">
				<li class="sub-menu-item"><a href="#popup-gs">Global Service /Russia Center</a></li>
				<li class="sub-menu-item"><a href="#popup-sc">Service Concep</a></li>
				<li class="sub-menu-item"><a href="#popup-as">After-Sale Service</a></li>
				<li class="sub-menu-item"><a href="#popup-ts">Technology Support</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Contact">Contact Us</a></div>
	</div> -->
</nav>
			</div>
		</div>
		<div class="bottom-wrapper">
			<div class="container">
				<div class="language">
    <button class="button-lang">Language</button>
	<div class="sub-lang">
		<a href="../cn/">中文</a>
		<a href="https://greennovo.pro">English</a>
	</div>
</div>
                
<!-- Поиск -->
		<!--<form action="https://tihomirtruvor.github.io/" method="GET" class="search">
	<input type="search" name="Search" class="main-search" placeholder="Search">

	<input type="submit" value=" " class="search-button" title="Go search">
</form>-->
<!-- Мобильный поиск -->
<!--	<input type="button" value=" " class="mobile-search-button" title="Mobile search">	
	<input type="button" value=" " class="mobile-close-search" title="Закрыть поиск">-->

			</div>
		</div>
	</header>
<!-- Слайдер -->
	<div class="swiper">
	<div class="swiper-wrapper">
	    <div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Front Motor <span class="last-word">F-Series</span></h1>
					<span class="slider-text">Big Torque, Noiseless and Strong Power are key characteristic for F-Series motors. FAT Greennovo motor is remarkable for its high efficiency with technical innovation.</span>
					<a class="slider-button" href="../front-motor-f-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="/assets/components/phpthumbof/cache/Slide21.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background 2 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="/assets/components/phpthumbof/cache/mobSlide21.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background 2 slide" width="750" height="750">
		</div>
		<div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Rear motor <span class="last-word">R-series</span></h1>
					<span class="slider-text">R-series are in High Power, Low noise and High Efficiency. All with compact design to get higher Torque. Extremely Comfortable for cycling.</span>
					<a class="slider-button" href="../rear-motor-r-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="/assets/components/phpthumbof/cache/Slide1-opt.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background 1 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="/assets/components/phpthumbof/cache/mobSlide1.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background 1 slide" width="750" height="750">
		</div>
	</div>
</div>
 <!-- Контент -->
	<main class="main-content">
	<!-- Категории -->
		<section class="categories">
	<div class="left-container el-animation">
		<div class="product">
			<a href="../center/">
				<img class="img-product" src="/assets/components/phpthumbof/cache/pr-center.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background categories">
				<img class="mobile-img-product" src="/assets/components/phpthumbof/cache/mob-pr-center.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background categories">
				<div class="h2-content">
					<h2>Product center</h2>
				</div>
			</a>
		</div>
	</div>
	<div class="right-container el-animation">
		<div class="innovation">
			<a href="../innovation.html">
				<img class="img-innovation" src="/assets/components/phpthumbof/cache/innovation.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background innovation">
				<img class="mobile-img-innovation" src="/assets/components/phpthumbof/cache/mob-innovation.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background innovation">
				<div class="h2-content">
					<h2>R&D INNOVATION</h2>
				</div>
			</a>
		</div>
		<div class="about-greennovo">
			<a href="../about-greennovo.html">
				<img class="img-about" src="/assets/components/phpthumbof/cache/about-greennovo.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background about greennovo">
				<img class="mobile-img-about" src="/assets/components/phpthumbof/cache/mob-about-greennovo.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background about greennovo">
				<div class="h2-content">
					<h2>Greennovo</h2>
				</div>
			</a>
		</div>
	</div>
</section>
	<!-- Статистика -->
		 <!--<section class="statistic" id="Stat">
	<img src="/assets/img/statistic.jpg" alt="Фон статистики"> <!-- Временная заглушка
</section> -->
	</main>
<!-- Поддержка -->
	<section class="support">
		<div class="container">
			<div class="nav-support el-animation">
	<h3>Support&Service</h3>
	<div class="nav-support-item">
		<a href="../support-and-service.html">Global Service Concept</a>
		<!--<div class="popup" id="popup-gs">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Global Service /Russia Center</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*global_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="../support-and-service.html">After-Sale Service</a>
		<!--<div class="popup" id="popup-as">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>After-Sale Service</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*after_sale_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<!--<div class="nav-support-item">
		<a href="#popup-ts">Technology Support</a>
		<div class="popup" id="popup-ts">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Technology Support</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*technology_support_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="#popup-sc">Service Concep</a>
		<div class="popup" id="popup-sc">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Service Concep</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*service_concep_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>-->
</div>
<div class="img-support el-animation">
	<img src="/assets/components/phpthumbof/cache/support.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="image support">
</div>
		</div>
	</section>
<!-- Контакты -->
	<section class="contacts" id="contact">
		<div class="content">
			<div class="left-container el-animation">
    <div class="phone-wrapper">
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)18682128829</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)13068711319</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86) 2286857225</a>
					</div>
				</div>
				<div class="other-wrapper">
					<div class="left info">
						<a href="mailto:sales@greennovo.pro"><img class="left-item icon-sale" src="assets/img/icon-email.svg" alt="иконка e-mail" width="40" height="40">sales@greennovo.pro</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+8618682128829" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +8618682128829</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+79266494149" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +79266494149</a>
					</div>
				</div>
	<!--<div class="left sale">
		<a href="mailto:sales@greentest.cn"><img class="left-item icon-sale" src="/assets/img/icon-handshake.svg" alt="иконка e-mail" width="40" height="40">sales@greentest.cn</a>
	</div>-->

<!--Форма обратной связи (Вызов сниппета)-->
	[[!AjaxForm?
    &snippet=`FormIt`
    &form=`contact-form_en`
    &emailTpl=`tpl-email`
    &hooks=`email`
    &emailSubject=`Message from the site Greennovo.pro`
    &emailTo=`artembmaximov@mail.ru`
    &emailFrom=`support@greennovo.pro`
    &validate=`email:email:required`
    &validationErrorMessage=`Error`
    &successMessage=`OK`
]]
	
</div>
			<div class="right-container el-animation">
	<div class="address">
		<img class="icon-address" src="/assets/img/map-marker.svg" alt="иконка указателя на карте" width="40" height="40">
		<a href="https://j.map.baidu.com/3d/6MAc" target="_blank">No.8, Huaxia Road, Science and Technology Park, Tianjin Beichen Economic and Technological Development Zone, Beichen District, Tianjin,China</a> 
	</div>
	<div class="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3686.3840307600894!2d113.91628141495802!3d22.489770285225376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s17G%2CPHASE%20II%2CSHUIWAN%201979%2C%20CHINA%20MERCHANTS%20STREET%2CNANSHAN%20DISTRICT%2CSHENZHEN!5e0!3m2!1sru!2sru!4v1633532019425!5m2!1sru!2sru" allowfullscreen="" loading="lazy"></iframe>
	</div>
</div>
		</div>
	</section>
<!-- Футер -->
	<footer class="footer">
		<div class="footer-top-wrapper">
    <div class="container">
    	<ul class="list-1">
    		<li><a href="../about-greennovo.html">About Greennovo</a></li>
    		<li><a href="../innovation.html">R&D Innovation</a></li>
    		<!--<li><a href="#Stat">Statistics</a></li>-->
    		<li><a href="../support-and-service.html">Support&Service</a></li>
    		<li><a href="../privacy-policy.html">Privacy policy</a></li>
    	</ul>
    	<ul class="list-2">
    	    <li class="list-2-item"><a href="../front-motor-f-series.html">Front Motor F-Series</a></li>
    		<li class="list-2-item"><a href="../rear-motor-r-series.html">Rear Motor R-Series</a></li>
    		<li class="list-2-item"><a href="../battery/">Battery</a></li>
    		<li class="list-2-item"><a href="../display/">Display</a></li>
    		<li class="list-2-item"><a href="../controller/">Controller</a></li>
    		<li class="mob-list-2-prod"><a href="../product-center/">Product center</a></li>
    	</ul>
    	<ul class="soc-1">
    		<li><a class="weechat" href="https://msngr.link/wc/79871170012" target="_blank"><img src="/assets/img/icon-weechat.svg" alt="иконка Вичата">WeChat: lihaistas</a></li>
    		<li><a href="https://api.whatsapp.com/send?phone=8613632527554" target="_blank"><img src="/assets/img/icon-whatsapp.svg" alt="иконка WhatsApp">WhatsApp: +8613632527554</a></li>
    	</ul>
    	<!--<ul class="soc-2">
    		<li><a href="https://www.facebook.com/greentest.official" target="_blank"><img src="/assets/img/icon-facebook.svg" alt="иконка Facebook">Facebook</a></li>
    		<li><a href="https://www.youtube.com/channel/UCisopLJJey-qrG2k5Qy3iAg" target="_blank"><img src="/assets/img/icon-youtube.svg" alt="иконка YouTube">You Tube</a></li>
    		<li><a href="https://www.instagram.com/greentest.official" target="_blank"><img src="/assets/img/icon-instagram.svg" alt="иконка Instagram">Instagram</a></li>
    	</ul>-->
    </div>
</div>
		<div class="footer-bottom-wrapper">
	<p class="footer-text">&#169; <!-- Знак копирайта-->
		<script>document.write(new Date().getFullYear());</script><!-- Автоизменение года-->
		 Greennovo Science & Technology Co., LTD</p>
</div>
<div id="cookie_notification"><!-- Куки-->
	<p>By using the greennovo.pro website, I consent to the processing of my personal data using cookies and third-party services and accept the terms of the <a href="../privacy-policy.html">Privacy Policy</a></p>
	<button class="button cookie_accept">Accept</button>
</div>

	</footer>

<!-- Стрелка наверх -->
	<a class="back-to-top" title="Наверх">
	<img src="/assets/img/angle-up.svg" alt="иконка Наверх">
</a>

	<!--Подключение библиотеки jQuery-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<!-- СКРИПТЫ -->
<script src="/assets/scripts.js"></script>
<script src="/assets/animation.js"></script><!-- Плавная загрузка блоков --> 
<script src="/assets/language.js"></script>
<!-- Свайпер -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

	<script type="text/javascript">
    //Свайпер
    let swiper = new Swiper(\'.swiper\', {
        
    	autoplay: {
    		delay: 4000,
    		disableOnInteraction: false, //остановка после ручной прокрутки
    	},
    
    	loop: true, //бесконечная прокрутка
    
    	speed: 1500, //скорость
    
    	keyboard: { //управление с клавы
    		enabled: true,
    		onlyInViewport: true,
    		pageUpDown: true,
    	},
    
    	effect: \'fade\', //Эффект появления
    		/*creativeEffect: {
    			prev: {
    				// will set `translateZ(-400px)` on previous slides
    				translate: [0, 0, -300],
    			},
    			next: {
    				// will set `translateX(100%)` on next slides
    				translate: [\'100%\', 0, 0],
    			},
    	},*/
    
    	//autoHeight: true, //автовысота
    	
/*lazy: { // поочередная загрузка картинок
	loadOnTransitionStart: false,
	loadPrevNext: false,
	},
preloadImages: true,*/
    
//parallax: true,
//grabCursor: true,
//slideToClickedSlide: true,
    });
</script>

</body>
</html>',
    '_isForward' => false,
  ),
  'contentType' => 
  array (
    'id' => 1,
    'name' => 'HTML',
    'description' => 'HTML content',
    'mime_type' => 'text/html',
    'file_extensions' => '.html',
    'headers' => 'a:0:{}',
    'binary' => 0,
  ),
  'policyCache' => 
  array (
  ),
  'elementCache' => 
  array (
    '[[$head]]' => '<head>
	<meta charset="UTF-8">
	
	<link type="image/x-icon" rel="shortcut icon" href="/assets/img/favicon_32.ico">
	<link type="image/png" sizes="16x16" rel="icon" href="/assets/img/favicon_16.png">
	<link type="image/png" sizes="32x32" rel="icon" href="/assets/img/favicon_32.png">
	<link type="image/png" sizes="96x96" rel="icon" href="/assets/img/favicon_96.png">
	<link type="image/png" sizes="120x120" rel="icon" href="/assets/img/favicon_120.png">

	<link rel="stylesheet" href="/assets/css/normalize.css">
	<link rel="stylesheet" href="/assets/css/style.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/><!--Свайпер-->

	<meta name="viewport" content="width=device-width">
	<meta name="description" content ="Houhua (Tianjin) Motive Power Technology Co., Ltd."/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<base href="[[!++site_url]]">

	<title>Home Greennovo</title>
</head>',
    '[[$logo]]' => '<a class="header-logo" href="index.html"> <!-- Логотип сайта -->
	<img src="/assets/img/logo.gif" width="95" height="68" alt="logo greennovo">
</a>',
    '[[pdoMenu? 
     &level=`2` 
     &parents=`0`
     &firstClass=``
     &lastClass=``
     &outerClass=`nav-wrapper`
     &tplOuter=`@INLINE <div [[+classes]]>[[+wrapper]]</div>`
     &tpl=`@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]</div>`
     &tplInner=`@INLINE <ul class="sub-menu">[[+wrapper]]</ul>`
     &tplInnerRow=`@INLINE <li><a href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]</li>`
     &tplParentRow=`@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]<div class="arrow-mini"></div></div>`
    ]]' => '<div  class="nav-wrapper"><div class="nav-item"><a class="nav-button" href="about-greennovo.html">About Greennovo</a></div><div class="nav-item"><a class="nav-button" href="center/">Product center</a><ul class="sub-menu"><li><a href="greennovo-motor/">Greennovo Motor</a></li><li><a href="battery/">Battery</a></li><li><a href="display/">Display</a></li><li><a href="controller/">Controller</a></li></ul><div class="arrow-mini"></div></div><div class="nav-item"><a class="nav-button" href="innovation.html">R&D Innovation</a></div><div class="nav-item"><a class="nav-button" href="support-and-service.html">Support&Service</a></div></div>',
    '[[$navigation]]' => '<nav class="navigation">
	<input id="menu__toggle" type="checkbox" /><!--Для мобильного меню-->
	<label class="menu__btn" for="menu__toggle"><!--Для мобильного меню-->
		<span></span>
	</label>
<!-- Вывод меню -->
<div class="container1">
    <div  class="nav-wrapper"><div class="nav-item"><a class="nav-button" href="about-greennovo.html">About Greennovo</a></div><div class="nav-item"><a class="nav-button" href="center/">Product center</a><ul class="sub-menu"><li><a href="greennovo-motor/">Greennovo Motor</a></li><li><a href="battery/">Battery</a></li><li><a href="display/">Display</a></li><li><a href="controller/">Controller</a></li></ul><div class="arrow-mini"></div></div><div class="nav-item"><a class="nav-button" href="innovation.html">R&D Innovation</a></div><div class="nav-item"><a class="nav-button" href="support-and-service.html">Support&Service</a></div></div>
    <div class="nav-item"><a class="nav-button" href="#contact">Contact Us</a></div>
</div>
	<!--
	&tplHere = `@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a></div>[[+wrapper]]` [[Для активного пункта меню]]
	<div class="container1">
	
	&tplParentRow = `@INLINE <div class="nav-item">
                                <a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]
                            </div>` [[Для родительского пункта меню]]
	    <div wra>
		<div class="nav-item">
			<a class="nav-button" href="#">About Greennovo</a>
		</div>
		<div class="nav-item">
			<a class="nav-button" href="#">Product Center</a>
			<ul class="sub-menu">
				<li><a href="#">Greennovo Motor</a></li>
				<li><a href="#">Battery</a></li>
				<li><a href="#">Display</a></li>
				<li><a href="#">Controller</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#">R&D Innovation</a>
			<ul class="sub-menu">
				<li><a href="#">Innovation Idea</a></li>
				<li><a href="#">Qualification Certificates</a></li>
				<li><a href="#">Test Laboratory</a></li>
				<li><a href="#">Manufacturing Base</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Support">Support&Service</a>
			<ul class="sub-menu">
				<li class="sub-menu-item"><a href="#popup-gs">Global Service /Russia Center</a></li>
				<li class="sub-menu-item"><a href="#popup-sc">Service Concep</a></li>
				<li class="sub-menu-item"><a href="#popup-as">After-Sale Service</a></li>
				<li class="sub-menu-item"><a href="#popup-ts">Technology Support</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Contact">Contact Us</a></div>
	</div> -->
</nav>',
    '[[$lang_en]]' => '<div class="language">
    <button class="button-lang">Language</button>
	<div class="sub-lang">
		<a href="../cn/">中文</a>
		<a href="https://greennovo.pro">English</a>
	</div>
</div>',
    '[[pdoCrumbs?
	&showAtHome=`0`
	&showHome=`1`
	&tpl=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`
    &tplHome=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a rel="nofollow" title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`   
	&tplWrapper=`@INLINE <ol itemscope="" itemtype="http://schema.org/BreadcrumbList" class="breadcrumb">[[+output]]</ol>`
	&tplCurrent=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem" class="active"><a title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`
    &outputSeparator=`&nbsp;»&nbsp;`

]]' => '',
    '[[$BreadCrumbs]]' => '',
    '[[$search]]' => '<!--<form action="https://tihomirtruvor.github.io/" method="GET" class="search">
	<input type="search" name="Search" class="main-search" placeholder="Search">

	<input type="submit" value=" " class="search-button" title="Go search">
</form>-->
<!-- Мобильный поиск -->
<!--	<input type="button" value=" " class="mobile-search-button" title="Mobile search">	
	<input type="button" value=" " class="mobile-close-search" title="Закрыть поиск">-->
',
    '[[$slider_en]]' => '<div class="swiper">
	<div class="swiper-wrapper">
	    <div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Front Motor <span class="last-word">F-Series</span></h1>
					<span class="slider-text">Big Torque, Noiseless and Strong Power are key characteristic for F-Series motors. FAT Greennovo motor is remarkable for its high efficiency with technical innovation.</span>
					<a class="slider-button" href="../front-motor-f-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="/assets/components/phpthumbof/cache/Slide21.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background 2 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="/assets/components/phpthumbof/cache/mobSlide21.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background 2 slide" width="750" height="750">
		</div>
		<div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Rear motor <span class="last-word">R-series</span></h1>
					<span class="slider-text">R-series are in High Power, Low noise and High Efficiency. All with compact design to get higher Torque. Extremely Comfortable for cycling.</span>
					<a class="slider-button" href="../rear-motor-r-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="/assets/components/phpthumbof/cache/Slide1-opt.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background 1 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="/assets/components/phpthumbof/cache/mobSlide1.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background 1 slide" width="750" height="750">
		</div>
	</div>
</div>',
    '[[$categories_en]]' => '<section class="categories">
	<div class="left-container el-animation">
		<div class="product">
			<a href="../center/">
				<img class="img-product" src="/assets/components/phpthumbof/cache/pr-center.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background categories">
				<img class="mobile-img-product" src="/assets/components/phpthumbof/cache/mob-pr-center.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background categories">
				<div class="h2-content">
					<h2>Product center</h2>
				</div>
			</a>
		</div>
	</div>
	<div class="right-container el-animation">
		<div class="innovation">
			<a href="../innovation.html">
				<img class="img-innovation" src="/assets/components/phpthumbof/cache/innovation.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background innovation">
				<img class="mobile-img-innovation" src="/assets/components/phpthumbof/cache/mob-innovation.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background innovation">
				<div class="h2-content">
					<h2>R&D INNOVATION</h2>
				</div>
			</a>
		</div>
		<div class="about-greennovo">
			<a href="../about-greennovo.html">
				<img class="img-about" src="/assets/components/phpthumbof/cache/about-greennovo.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="background about greennovo">
				<img class="mobile-img-about" src="/assets/components/phpthumbof/cache/mob-about-greennovo.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="mobile background about greennovo">
				<div class="h2-content">
					<h2>Greennovo</h2>
				</div>
			</a>
		</div>
	</div>
</section>',
    '[[$statistic]]' => '<!--<section class="statistic" id="Stat">
	<img src="/assets/img/statistic.jpg" alt="Фон статистики"> <!-- Временная заглушка
</section> -->',
    '[[$support_in_index_en]]' => '<div class="nav-support el-animation">
	<h3>Support&Service</h3>
	<div class="nav-support-item">
		<a href="../support-and-service.html">Global Service Concept</a>
		<!--<div class="popup" id="popup-gs">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Global Service /Russia Center</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*global_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="../support-and-service.html">After-Sale Service</a>
		<!--<div class="popup" id="popup-as">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>After-Sale Service</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*after_sale_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<!--<div class="nav-support-item">
		<a href="#popup-ts">Technology Support</a>
		<div class="popup" id="popup-ts">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Technology Support</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*technology_support_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="#popup-sc">Service Concep</a>
		<div class="popup" id="popup-sc">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Service Concep</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*service_concep_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>-->
</div>
<div class="img-support el-animation">
	<img src="/assets/components/phpthumbof/cache/support.a87f4cf9306bc1933a3398b0de0c6e731.jpg" alt="image support">
</div>',
    '[[$left-contacts_en]]' => '<div class="left-container el-animation">
    <div class="phone-wrapper">
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)18682128829</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)13068711319</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86) 2286857225</a>
					</div>
				</div>
				<div class="other-wrapper">
					<div class="left info">
						<a href="mailto:sales@greennovo.pro"><img class="left-item icon-sale" src="assets/img/icon-email.svg" alt="иконка e-mail" width="40" height="40">sales@greennovo.pro</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+8618682128829" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +8618682128829</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+79266494149" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +79266494149</a>
					</div>
				</div>
	<!--<div class="left sale">
		<a href="mailto:sales@greentest.cn"><img class="left-item icon-sale" src="/assets/img/icon-handshake.svg" alt="иконка e-mail" width="40" height="40">sales@greentest.cn</a>
	</div>-->

<!--Форма обратной связи (Вызов сниппета)-->
	[[!AjaxForm?
    &snippet=`FormIt`
    &form=`contact-form_en`
    &emailTpl=`tpl-email`
    &hooks=`email`
    &emailSubject=`Message from the site Greennovo.pro`
    &emailTo=`artembmaximov@mail.ru`
    &emailFrom=`support@greennovo.pro`
    &validate=`email:email:required`
    &validationErrorMessage=`Error`
    &successMessage=`OK`
]]
	
</div>',
    '[[$right-contacts_en]]' => '<div class="right-container el-animation">
	<div class="address">
		<img class="icon-address" src="/assets/img/map-marker.svg" alt="иконка указателя на карте" width="40" height="40">
		<a href="https://j.map.baidu.com/3d/6MAc" target="_blank">No.8, Huaxia Road, Science and Technology Park, Tianjin Beichen Economic and Technological Development Zone, Beichen District, Tianjin,China</a> 
	</div>
	<div class="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3686.3840307600894!2d113.91628141495802!3d22.489770285225376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s17G%2CPHASE%20II%2CSHUIWAN%201979%2C%20CHINA%20MERCHANTS%20STREET%2CNANSHAN%20DISTRICT%2CSHENZHEN!5e0!3m2!1sru!2sru!4v1633532019425!5m2!1sru!2sru" allowfullscreen="" loading="lazy"></iframe>
	</div>
</div>',
    '[[$top-footer_en]]' => '<div class="footer-top-wrapper">
    <div class="container">
    	<ul class="list-1">
    		<li><a href="../about-greennovo.html">About Greennovo</a></li>
    		<li><a href="../innovation.html">R&D Innovation</a></li>
    		<!--<li><a href="#Stat">Statistics</a></li>-->
    		<li><a href="../support-and-service.html">Support&Service</a></li>
    		<li><a href="../privacy-policy.html">Privacy policy</a></li>
    	</ul>
    	<ul class="list-2">
    	    <li class="list-2-item"><a href="../front-motor-f-series.html">Front Motor F-Series</a></li>
    		<li class="list-2-item"><a href="../rear-motor-r-series.html">Rear Motor R-Series</a></li>
    		<li class="list-2-item"><a href="../battery/">Battery</a></li>
    		<li class="list-2-item"><a href="../display/">Display</a></li>
    		<li class="list-2-item"><a href="../controller/">Controller</a></li>
    		<li class="mob-list-2-prod"><a href="../product-center/">Product center</a></li>
    	</ul>
    	<ul class="soc-1">
    		<li><a class="weechat" href="https://msngr.link/wc/79871170012" target="_blank"><img src="/assets/img/icon-weechat.svg" alt="иконка Вичата">WeChat: lihaistas</a></li>
    		<li><a href="https://api.whatsapp.com/send?phone=8613632527554" target="_blank"><img src="/assets/img/icon-whatsapp.svg" alt="иконка WhatsApp">WhatsApp: +8613632527554</a></li>
    	</ul>
    	<!--<ul class="soc-2">
    		<li><a href="https://www.facebook.com/greentest.official" target="_blank"><img src="/assets/img/icon-facebook.svg" alt="иконка Facebook">Facebook</a></li>
    		<li><a href="https://www.youtube.com/channel/UCisopLJJey-qrG2k5Qy3iAg" target="_blank"><img src="/assets/img/icon-youtube.svg" alt="иконка YouTube">You Tube</a></li>
    		<li><a href="https://www.instagram.com/greentest.official" target="_blank"><img src="/assets/img/icon-instagram.svg" alt="иконка Instagram">Instagram</a></li>
    	</ul>-->
    </div>
</div>',
    '[[$bottom-footer]]' => '<div class="footer-bottom-wrapper">
	<p class="footer-text">&#169; <!-- Знак копирайта-->
		<script>document.write(new Date().getFullYear());</script><!-- Автоизменение года-->
		 Greennovo Science & Technology Co., LTD</p>
</div>
<div id="cookie_notification"><!-- Куки-->
	<p>By using the greennovo.pro website, I consent to the processing of my personal data using cookies and third-party services and accept the terms of the <a href="../privacy-policy.html">Privacy Policy</a></p>
	<button class="button cookie_accept">Accept</button>
</div>
',
    '[[$arrow-top]]' => '<a class="back-to-top" title="Наверх">
	<img src="/assets/img/angle-up.svg" alt="иконка Наверх">
</a>',
    '[[$scripts]]' => '<!--Подключение библиотеки jQuery-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<!-- СКРИПТЫ -->
<script src="/assets/scripts.js"></script>
<script src="/assets/animation.js"></script><!-- Плавная загрузка блоков --> 
<script src="/assets/language.js"></script>
<!-- Свайпер -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
',
    '[[$swiper]]' => '<script type="text/javascript">
    //Свайпер
    let swiper = new Swiper(\'.swiper\', {
        
    	autoplay: {
    		delay: 4000,
    		disableOnInteraction: false, //остановка после ручной прокрутки
    	},
    
    	loop: true, //бесконечная прокрутка
    
    	speed: 1500, //скорость
    
    	keyboard: { //управление с клавы
    		enabled: true,
    		onlyInViewport: true,
    		pageUpDown: true,
    	},
    
    	effect: \'fade\', //Эффект появления
    		/*creativeEffect: {
    			prev: {
    				// will set `translateZ(-400px)` on previous slides
    				translate: [0, 0, -300],
    			},
    			next: {
    				// will set `translateX(100%)` on next slides
    				translate: [\'100%\', 0, 0],
    			},
    	},*/
    
    	//autoHeight: true, //автовысота
    	
/*lazy: { // поочередная загрузка картинок
	loadOnTransitionStart: false,
	loadPrevNext: false,
	},
preloadImages: true,*/
    
//parallax: true,
//grabCursor: true,
//slideToClickedSlide: true,
    });
</script>',
  ),
  'sourceCache' => 
  array (
    'modChunk' => 
    array (
      'head' => 
      array (
        'fields' => 
        array (
          'id' => 1,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'head',
          'description' => '',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<head>
	<meta charset="UTF-8">
	
	<link type="image/x-icon" rel="shortcut icon" href="/assets/img/favicon_32.ico">
	<link type="image/png" sizes="16x16" rel="icon" href="/assets/img/favicon_16.png">
	<link type="image/png" sizes="32x32" rel="icon" href="/assets/img/favicon_32.png">
	<link type="image/png" sizes="96x96" rel="icon" href="/assets/img/favicon_96.png">
	<link type="image/png" sizes="120x120" rel="icon" href="/assets/img/favicon_120.png">

	<link rel="stylesheet" href="/assets/css/normalize.css">
	<link rel="stylesheet" href="/assets/css/style.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/><!--Свайпер-->

	<meta name="viewport" content="width=device-width">
	<meta name="description" content ="[[*description]]"/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<base href="[[!++site_url]]">

	<title>[[*pagetitle:isnot=``:then=`[[*pagetitle]]`:else=`[[*longtitle]]`]]</title>
</head>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<head>
	<meta charset="UTF-8">
	
	<link type="image/x-icon" rel="shortcut icon" href="/assets/img/favicon_32.ico">
	<link type="image/png" sizes="16x16" rel="icon" href="/assets/img/favicon_16.png">
	<link type="image/png" sizes="32x32" rel="icon" href="/assets/img/favicon_32.png">
	<link type="image/png" sizes="96x96" rel="icon" href="/assets/img/favicon_96.png">
	<link type="image/png" sizes="120x120" rel="icon" href="/assets/img/favicon_120.png">

	<link rel="stylesheet" href="/assets/css/normalize.css">
	<link rel="stylesheet" href="/assets/css/style.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/><!--Свайпер-->

	<meta name="viewport" content="width=device-width">
	<meta name="description" content ="[[*description]]"/>

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<base href="[[!++site_url]]">

	<title>[[*pagetitle:isnot=``:then=`[[*pagetitle]]`:else=`[[*longtitle]]`]]</title>
</head>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'logo' => 
      array (
        'fields' => 
        array (
          'id' => 2,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'logo',
          'description' => 'Логотип',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<a class="header-logo" href="index.html"> <!-- Логотип сайта -->
	<img src="/assets/img/logo.gif" width="95" height="68" alt="logo greennovo">
</a>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<a class="header-logo" href="index.html"> <!-- Логотип сайта -->
	<img src="/assets/img/logo.gif" width="95" height="68" alt="logo greennovo">
</a>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'navigation' => 
      array (
        'fields' => 
        array (
          'id' => 3,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'navigation',
          'description' => 'Меню сайта',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<nav class="navigation">
	<input id="menu__toggle" type="checkbox" /><!--Для мобильного меню-->
	<label class="menu__btn" for="menu__toggle"><!--Для мобильного меню-->
		<span></span>
	</label>
<!-- Вывод меню -->
<div class="container1">
    [[pdoMenu? 
     &level=`2` 
     &parents=`0`
     &firstClass=``
     &lastClass=``
     &outerClass=`nav-wrapper`
     &tplOuter=`@INLINE <div [[+classes]]>[[+wrapper]]</div>`
     &tpl=`@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]</div>`
     &tplInner=`@INLINE <ul class="sub-menu">[[+wrapper]]</ul>`
     &tplInnerRow=`@INLINE <li><a href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]</li>`
     &tplParentRow=`@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]<div class="arrow-mini"></div></div>`
    ]]
    <div class="nav-item"><a class="nav-button" href="#contact">[[*nav-contact]]</a></div>
</div>
	<!--
	&tplHere = `@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a></div>[[+wrapper]]` [[Для активного пункта меню]]
	<div class="container1">
	
	&tplParentRow = `@INLINE <div class="nav-item">
                                <a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]
                            </div>` [[Для родительского пункта меню]]
	    <div wra>
		<div class="nav-item">
			<a class="nav-button" href="#">About Greennovo</a>
		</div>
		<div class="nav-item">
			<a class="nav-button" href="#">Product Center</a>
			<ul class="sub-menu">
				<li><a href="#">Greennovo Motor</a></li>
				<li><a href="#">Battery</a></li>
				<li><a href="#">Display</a></li>
				<li><a href="#">Controller</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#">R&D Innovation</a>
			<ul class="sub-menu">
				<li><a href="#">Innovation Idea</a></li>
				<li><a href="#">Qualification Certificates</a></li>
				<li><a href="#">Test Laboratory</a></li>
				<li><a href="#">Manufacturing Base</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Support">Support&Service</a>
			<ul class="sub-menu">
				<li class="sub-menu-item"><a href="#popup-gs">Global Service /Russia Center</a></li>
				<li class="sub-menu-item"><a href="#popup-sc">Service Concep</a></li>
				<li class="sub-menu-item"><a href="#popup-as">After-Sale Service</a></li>
				<li class="sub-menu-item"><a href="#popup-ts">Technology Support</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Contact">Contact Us</a></div>
	</div> -->
</nav>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<nav class="navigation">
	<input id="menu__toggle" type="checkbox" /><!--Для мобильного меню-->
	<label class="menu__btn" for="menu__toggle"><!--Для мобильного меню-->
		<span></span>
	</label>
<!-- Вывод меню -->
<div class="container1">
    [[pdoMenu? 
     &level=`2` 
     &parents=`0`
     &firstClass=``
     &lastClass=``
     &outerClass=`nav-wrapper`
     &tplOuter=`@INLINE <div [[+classes]]>[[+wrapper]]</div>`
     &tpl=`@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]</div>`
     &tplInner=`@INLINE <ul class="sub-menu">[[+wrapper]]</ul>`
     &tplInnerRow=`@INLINE <li><a href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]</li>`
     &tplParentRow=`@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]<div class="arrow-mini"></div></div>`
    ]]
    <div class="nav-item"><a class="nav-button" href="#contact">[[*nav-contact]]</a></div>
</div>
	<!--
	&tplHere = `@INLINE <div class="nav-item"><a class="nav-button" href="[[+link]]">[[+menutitle]]</a></div>[[+wrapper]]` [[Для активного пункта меню]]
	<div class="container1">
	
	&tplParentRow = `@INLINE <div class="nav-item">
                                <a class="nav-button" href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]
                            </div>` [[Для родительского пункта меню]]
	    <div wra>
		<div class="nav-item">
			<a class="nav-button" href="#">About Greennovo</a>
		</div>
		<div class="nav-item">
			<a class="nav-button" href="#">Product Center</a>
			<ul class="sub-menu">
				<li><a href="#">Greennovo Motor</a></li>
				<li><a href="#">Battery</a></li>
				<li><a href="#">Display</a></li>
				<li><a href="#">Controller</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#">R&D Innovation</a>
			<ul class="sub-menu">
				<li><a href="#">Innovation Idea</a></li>
				<li><a href="#">Qualification Certificates</a></li>
				<li><a href="#">Test Laboratory</a></li>
				<li><a href="#">Manufacturing Base</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Support">Support&Service</a>
			<ul class="sub-menu">
				<li class="sub-menu-item"><a href="#popup-gs">Global Service /Russia Center</a></li>
				<li class="sub-menu-item"><a href="#popup-sc">Service Concep</a></li>
				<li class="sub-menu-item"><a href="#popup-as">After-Sale Service</a></li>
				<li class="sub-menu-item"><a href="#popup-ts">Technology Support</a></li>
			</ul>
			<div class="arrow-mini"></div>
		</div>
		<div class="nav-item"><a class="nav-button" href="#Contact">Contact Us</a></div>
	</div> -->
</nav>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'lang_en' => 
      array (
        'fields' => 
        array (
          'id' => 4,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'lang_en',
          'description' => 'Переключение языка',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<div class="language">
    <button class="button-lang">Language</button>
	<div class="sub-lang">
		<a href="../cn/">中文</a>
		<a href="https://greennovo.pro">English</a>
	</div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="language">
    <button class="button-lang">Language</button>
	<div class="sub-lang">
		<a href="../cn/">中文</a>
		<a href="https://greennovo.pro">English</a>
	</div>
</div>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'BreadCrumbs' => 
      array (
        'fields' => 
        array (
          'id' => 48,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'BreadCrumbs',
          'description' => 'Хлебные крошки',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '[[pdoCrumbs?
	&showAtHome=`0`
	&showHome=`1`
	&tpl=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`
    &tplHome=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a rel="nofollow" title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`   
	&tplWrapper=`@INLINE <ol itemscope="" itemtype="http://schema.org/BreadcrumbList" class="breadcrumb">[[+output]]</ol>`
	&tplCurrent=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem" class="active"><a title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`
    &outputSeparator=`&nbsp;»&nbsp;`

]]',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '[[pdoCrumbs?
	&showAtHome=`0`
	&showHome=`1`
	&tpl=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`
    &tplHome=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem"><a rel="nofollow" title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`   
	&tplWrapper=`@INLINE <ol itemscope="" itemtype="http://schema.org/BreadcrumbList" class="breadcrumb">[[+output]]</ol>`
	&tplCurrent=`@INLINE <li itemscope="" itemprop="itemListElement" itemtype="http://schema.org/ListItem" class="active"><a title="[[+menutitle]]" itemprop="item" href="[[+link]]"><span itemprop="name">[[+menutitle]]</span><meta itemprop="position" content="[[+idx]]"></a></li>`
    &outputSeparator=`&nbsp;»&nbsp;`

]]',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'search' => 
      array (
        'fields' => 
        array (
          'id' => 5,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'search',
          'description' => 'Поиск и мобильный поиск',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<!--<form action="https://tihomirtruvor.github.io/" method="GET" class="search">
	<input type="search" name="Search" class="main-search" placeholder="Search">

	<input type="submit" value=" " class="search-button" title="Go search">
</form>-->
<!-- Мобильный поиск -->
<!--	<input type="button" value=" " class="mobile-search-button" title="Mobile search">	
	<input type="button" value=" " class="mobile-close-search" title="Закрыть поиск">-->
',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<!--<form action="https://tihomirtruvor.github.io/" method="GET" class="search">
	<input type="search" name="Search" class="main-search" placeholder="Search">

	<input type="submit" value=" " class="search-button" title="Go search">
</form>-->
<!-- Мобильный поиск -->
<!--	<input type="button" value=" " class="mobile-search-button" title="Mobile search">	
	<input type="button" value=" " class="mobile-close-search" title="Закрыть поиск">-->
',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'slider_en' => 
      array (
        'fields' => 
        array (
          'id' => 6,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'slider_en',
          'description' => 'Главный слайдер',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<div class="swiper">
	<div class="swiper-wrapper">
	    <div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Front Motor <span class="last-word">F-Series</span></h1>
					<span class="slider-text">[[*text-slide2]]</span>
					<a class="slider-button" href="../front-motor-f-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="[[*image-slide2:phpthumbof = \'w=1920&h=750&zc=1\']]" alt="background 2 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="[[*mobile-image-slide2:phpthumbof = \'w=750&h=750&zc=1\']]" alt="mobile background 2 slide" width="750" height="750">
		</div>
		<div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Rear motor <span class="last-word">R-series</span></h1>
					<span class="slider-text">[[*text-slide1]]</span>
					<a class="slider-button" href="../rear-motor-r-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="[[*image-slide1:phpthumbof = \'w=1920&h=750&zc=1\']]" alt="background 1 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="[[*mobile-image-slide1:phpthumbof = \'w=750&h=750&zc=1\']]" alt="mobile background 1 slide" width="750" height="750">
		</div>
	</div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="swiper">
	<div class="swiper-wrapper">
	    <div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Front Motor <span class="last-word">F-Series</span></h1>
					<span class="slider-text">[[*text-slide2]]</span>
					<a class="slider-button" href="../front-motor-f-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="[[*image-slide2:phpthumbof = \'w=1920&h=750&zc=1\']]" alt="background 2 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="[[*mobile-image-slide2:phpthumbof = \'w=750&h=750&zc=1\']]" alt="mobile background 2 slide" width="750" height="750">
		</div>
		<div class="slider swiper-slide">
			<div class="content">
				<div class="container ">
					<h1>Rear motor <span class="last-word">R-series</span></h1>
					<span class="slider-text">[[*text-slide1]]</span>
					<a class="slider-button" href="../rear-motor-r-series.html">More details</a>
				</div>
			</div>
			<img class="back-image swiper-lazy" src="[[*image-slide1:phpthumbof = \'w=1920&h=750&zc=1\']]" alt="background 1 slide" width="1920" height="750">
			<img class="mobile-back-image swiper-lazy" src="[[*mobile-image-slide1:phpthumbof = \'w=750&h=750&zc=1\']]" alt="mobile background 1 slide" width="750" height="750">
		</div>
	</div>
</div>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'categories_en' => 
      array (
        'fields' => 
        array (
          'id' => 7,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'categories_en',
          'description' => 'Блок категорий на сайте',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<section class="categories">
	<div class="left-container el-animation">
		<div class="product">
			<a href="../center/">
				<img class="img-product" src="[[*image_product:phpthumbof = \'w=590&h=800&zc=1\']]" alt="background categories">
				<img class="mobile-img-product" src="[[*mobile_image_product:phpthumbof = \'w=800&h=500&zc=1\']]" alt="mobile background categories">
				<div class="h2-content">
					<h2>[[*product-title]]</h2>
				</div>
			</a>
		</div>
	</div>
	<div class="right-container el-animation">
		<div class="innovation">
			<a href="../innovation.html">
				<img class="img-innovation" src="[[*image_innovation:phpthumbof = \'w=590&h=390&zc=1\']]" alt="background innovation">
				<img class="mobile-img-innovation" src="[[*mobile_image_innovation:phpthumbof = \'w=800&h=500&zc=1\']]" alt="mobile background innovation">
				<div class="h2-content">
					<h2>[[*rd-innovation-title]]</h2>
				</div>
			</a>
		</div>
		<div class="about-greennovo">
			<a href="../about-greennovo.html">
				<img class="img-about" src="[[*image_about_gteennovo:phpthumbof = \'w=590&h=390&zc=1\']]" alt="background about greennovo">
				<img class="mobile-img-about" src="[[*mobile_image_about_gteennovo:phpthumbof = \'w=800&h=500&zc=1\']]" alt="mobile background about greennovo">
				<div class="h2-content">
					<h2>[[*about-title]]</h2>
				</div>
			</a>
		</div>
	</div>
</section>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<section class="categories">
	<div class="left-container el-animation">
		<div class="product">
			<a href="../center/">
				<img class="img-product" src="[[*image_product:phpthumbof = \'w=590&h=800&zc=1\']]" alt="background categories">
				<img class="mobile-img-product" src="[[*mobile_image_product:phpthumbof = \'w=800&h=500&zc=1\']]" alt="mobile background categories">
				<div class="h2-content">
					<h2>[[*product-title]]</h2>
				</div>
			</a>
		</div>
	</div>
	<div class="right-container el-animation">
		<div class="innovation">
			<a href="../innovation.html">
				<img class="img-innovation" src="[[*image_innovation:phpthumbof = \'w=590&h=390&zc=1\']]" alt="background innovation">
				<img class="mobile-img-innovation" src="[[*mobile_image_innovation:phpthumbof = \'w=800&h=500&zc=1\']]" alt="mobile background innovation">
				<div class="h2-content">
					<h2>[[*rd-innovation-title]]</h2>
				</div>
			</a>
		</div>
		<div class="about-greennovo">
			<a href="../about-greennovo.html">
				<img class="img-about" src="[[*image_about_gteennovo:phpthumbof = \'w=590&h=390&zc=1\']]" alt="background about greennovo">
				<img class="mobile-img-about" src="[[*mobile_image_about_gteennovo:phpthumbof = \'w=800&h=500&zc=1\']]" alt="mobile background about greennovo">
				<div class="h2-content">
					<h2>[[*about-title]]</h2>
				</div>
			</a>
		</div>
	</div>
</section>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'statistic' => 
      array (
        'fields' => 
        array (
          'id' => 8,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'statistic',
          'description' => 'блок статистики',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<!--<section class="statistic" id="Stat">
	<img src="/assets/img/statistic.jpg" alt="Фон статистики"> <!-- Временная заглушка
</section> -->',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<!--<section class="statistic" id="Stat">
	<img src="/assets/img/statistic.jpg" alt="Фон статистики"> <!-- Временная заглушка
</section> -->',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'support_in_index_en' => 
      array (
        'fields' => 
        array (
          'id' => 9,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'support_in_index_en',
          'description' => 'блок поддержки и сервиса',
          'editor_type' => 0,
          'category' => 2,
          'cache_type' => 0,
          'snippet' => '<div class="nav-support el-animation">
	<h3>[[*support-title]]</h3>
	<div class="nav-support-item">
		<a href="../support-and-service.html">Global Service Concept</a>
		<!--<div class="popup" id="popup-gs">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Global Service /Russia Center</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*global_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="../support-and-service.html">After-Sale Service</a>
		<!--<div class="popup" id="popup-as">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>After-Sale Service</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*after_sale_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<!--<div class="nav-support-item">
		<a href="#popup-ts">Technology Support</a>
		<div class="popup" id="popup-ts">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Technology Support</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*technology_support_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="#popup-sc">Service Concep</a>
		<div class="popup" id="popup-sc">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Service Concep</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*service_concep_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>-->
</div>
<div class="img-support el-animation">
	<img src="[[*image_support:phpthumbof = \'w=590&zc=1\']]" alt="image support">
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="nav-support el-animation">
	<h3>[[*support-title]]</h3>
	<div class="nav-support-item">
		<a href="../support-and-service.html">Global Service Concept</a>
		<!--<div class="popup" id="popup-gs">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Global Service /Russia Center</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*global_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="../support-and-service.html">After-Sale Service</a>
		<!--<div class="popup" id="popup-as">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>After-Sale Service</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*after_sale_service_text]]</p>
			</div>
		</div>-->
		<div class="arrow-mini"></div>
	</div>
	<!--<div class="nav-support-item">
		<a href="#popup-ts">Technology Support</a>
		<div class="popup" id="popup-ts">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Technology Support</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*technology_support_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>
	<div class="nav-support-item">
		<a href="#popup-sc">Service Concep</a>
		<div class="popup" id="popup-sc">
			<div class="popup-content">
				<div class="popup-top">
					<div class="popup-header">
						<h4>Service Concep</h4>
					</div>
						<a href="#Support">
							<div class="cl-btn-2">
								<div>
									<div class="leftright"></div>
									<div class="rightleft"></div>
								</div>
							</div> 
						</a>
				</div>
				<p class="popup-text">[[*service_concep_text]]</p>
			</div>
		</div>
		<div class="arrow-mini"></div>
	</div>-->
</div>
<div class="img-support el-animation">
	<img src="[[*image_support:phpthumbof = \'w=590&zc=1\']]" alt="image support">
</div>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'left-contacts_en' => 
      array (
        'fields' => 
        array (
          'id' => 10,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'left-contacts_en',
          'description' => 'левая часть блока контактов',
          'editor_type' => 0,
          'category' => 7,
          'cache_type' => 0,
          'snippet' => '<div class="left-container el-animation">
    <div class="phone-wrapper">
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)18682128829</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)13068711319</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86) 2286857225</a>
					</div>
				</div>
				<div class="other-wrapper">
					<div class="left info">
						<a href="mailto:sales@greennovo.pro"><img class="left-item icon-sale" src="assets/img/icon-email.svg" alt="иконка e-mail" width="40" height="40">sales@greennovo.pro</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+8618682128829" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +8618682128829</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+79266494149" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +79266494149</a>
					</div>
				</div>
	<!--<div class="left sale">
		<a href="mailto:sales@greentest.cn"><img class="left-item icon-sale" src="/assets/img/icon-handshake.svg" alt="иконка e-mail" width="40" height="40">sales@greentest.cn</a>
	</div>-->

<!--Форма обратной связи (Вызов сниппета)-->
	[[!AjaxForm?
    &snippet=`FormIt`
    &form=`contact-form_en`
    &emailTpl=`tpl-email`
    &hooks=`email`
    &emailSubject=`Message from the site Greennovo.pro`
    &emailTo=`artembmaximov@mail.ru`
    &emailFrom=`support@greennovo.pro`
    &validate=`email:email:required`
    &validationErrorMessage=`Error`
    &successMessage=`OK`
]]
	
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="left-container el-animation">
    <div class="phone-wrapper">
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)18682128829</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86)13068711319</a>
					</div>
					<div class="left phone">
						<a href="#contact"><img class="left-item icon-phone" src="assets/img/icon-phone.svg" alt="иконка телефона" width="40" height="40">+(86) 2286857225</a>
					</div>
				</div>
				<div class="other-wrapper">
					<div class="left info">
						<a href="mailto:sales@greennovo.pro"><img class="left-item icon-sale" src="assets/img/icon-email.svg" alt="иконка e-mail" width="40" height="40">sales@greennovo.pro</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+8618682128829" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +8618682128829</a>
					</div>
					<div class="left info">
						<a href="https://api.whatsapp.com/send?phone=+79266494149" target="_blank"><img src="assets/img/icon-whatsapp2.svg" alt="иконка WhatsApp" width="40" height="40">WhatsApp: +79266494149</a>
					</div>
				</div>
	<!--<div class="left sale">
		<a href="mailto:sales@greentest.cn"><img class="left-item icon-sale" src="/assets/img/icon-handshake.svg" alt="иконка e-mail" width="40" height="40">sales@greentest.cn</a>
	</div>-->

<!--Форма обратной связи (Вызов сниппета)-->
	[[!AjaxForm?
    &snippet=`FormIt`
    &form=`contact-form_en`
    &emailTpl=`tpl-email`
    &hooks=`email`
    &emailSubject=`Message from the site Greennovo.pro`
    &emailTo=`artembmaximov@mail.ru`
    &emailFrom=`support@greennovo.pro`
    &validate=`email:email:required`
    &validationErrorMessage=`Error`
    &successMessage=`OK`
]]
	
</div>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'right-contacts_en' => 
      array (
        'fields' => 
        array (
          'id' => 11,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'right-contacts_en',
          'description' => 'правая часть блока контактов',
          'editor_type' => 0,
          'category' => 7,
          'cache_type' => 0,
          'snippet' => '<div class="right-container el-animation">
	<div class="address">
		<img class="icon-address" src="/assets/img/map-marker.svg" alt="иконка указателя на карте" width="40" height="40">
		<a href="https://j.map.baidu.com/3d/6MAc" target="_blank">No.8, Huaxia Road, Science and Technology Park, Tianjin Beichen Economic and Technological Development Zone, Beichen District, Tianjin,China</a> 
	</div>
	<div class="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3686.3840307600894!2d113.91628141495802!3d22.489770285225376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s17G%2CPHASE%20II%2CSHUIWAN%201979%2C%20CHINA%20MERCHANTS%20STREET%2CNANSHAN%20DISTRICT%2CSHENZHEN!5e0!3m2!1sru!2sru!4v1633532019425!5m2!1sru!2sru" allowfullscreen="" loading="lazy"></iframe>
	</div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="right-container el-animation">
	<div class="address">
		<img class="icon-address" src="/assets/img/map-marker.svg" alt="иконка указателя на карте" width="40" height="40">
		<a href="https://j.map.baidu.com/3d/6MAc" target="_blank">No.8, Huaxia Road, Science and Technology Park, Tianjin Beichen Economic and Technological Development Zone, Beichen District, Tianjin,China</a> 
	</div>
	<div class="map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3686.3840307600894!2d113.91628141495802!3d22.489770285225376!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s17G%2CPHASE%20II%2CSHUIWAN%201979%2C%20CHINA%20MERCHANTS%20STREET%2CNANSHAN%20DISTRICT%2CSHENZHEN!5e0!3m2!1sru!2sru!4v1633532019425!5m2!1sru!2sru" allowfullscreen="" loading="lazy"></iframe>
	</div>
</div>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'top-footer_en' => 
      array (
        'fields' => 
        array (
          'id' => 12,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'top-footer_en',
          'description' => 'верхняя часть футера',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<div class="footer-top-wrapper">
    <div class="container">
    	<ul class="list-1">
    		<li><a href="../about-greennovo.html">About Greennovo</a></li>
    		<li><a href="../innovation.html">R&D Innovation</a></li>
    		<!--<li><a href="#Stat">Statistics</a></li>-->
    		<li><a href="../support-and-service.html">Support&Service</a></li>
    		<li><a href="../privacy-policy.html">Privacy policy</a></li>
    	</ul>
    	<ul class="list-2">
    	    <li class="list-2-item"><a href="../front-motor-f-series.html">Front Motor F-Series</a></li>
    		<li class="list-2-item"><a href="../rear-motor-r-series.html">Rear Motor R-Series</a></li>
    		<li class="list-2-item"><a href="../battery/">Battery</a></li>
    		<li class="list-2-item"><a href="../display/">Display</a></li>
    		<li class="list-2-item"><a href="../controller/">Controller</a></li>
    		<li class="mob-list-2-prod"><a href="../product-center/">Product center</a></li>
    	</ul>
    	<ul class="soc-1">
    		<li><a class="weechat" href="https://msngr.link/wc/79871170012" target="_blank"><img src="/assets/img/icon-weechat.svg" alt="иконка Вичата">WeChat: lihaistas</a></li>
    		<li><a href="https://api.whatsapp.com/send?phone=8613632527554" target="_blank"><img src="/assets/img/icon-whatsapp.svg" alt="иконка WhatsApp">WhatsApp: +8613632527554</a></li>
    	</ul>
    	<!--<ul class="soc-2">
    		<li><a href="https://www.facebook.com/greentest.official" target="_blank"><img src="/assets/img/icon-facebook.svg" alt="иконка Facebook">Facebook</a></li>
    		<li><a href="https://www.youtube.com/channel/UCisopLJJey-qrG2k5Qy3iAg" target="_blank"><img src="/assets/img/icon-youtube.svg" alt="иконка YouTube">You Tube</a></li>
    		<li><a href="https://www.instagram.com/greentest.official" target="_blank"><img src="/assets/img/icon-instagram.svg" alt="иконка Instagram">Instagram</a></li>
    	</ul>-->
    </div>
</div>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="footer-top-wrapper">
    <div class="container">
    	<ul class="list-1">
    		<li><a href="../about-greennovo.html">About Greennovo</a></li>
    		<li><a href="../innovation.html">R&D Innovation</a></li>
    		<!--<li><a href="#Stat">Statistics</a></li>-->
    		<li><a href="../support-and-service.html">Support&Service</a></li>
    		<li><a href="../privacy-policy.html">Privacy policy</a></li>
    	</ul>
    	<ul class="list-2">
    	    <li class="list-2-item"><a href="../front-motor-f-series.html">Front Motor F-Series</a></li>
    		<li class="list-2-item"><a href="../rear-motor-r-series.html">Rear Motor R-Series</a></li>
    		<li class="list-2-item"><a href="../battery/">Battery</a></li>
    		<li class="list-2-item"><a href="../display/">Display</a></li>
    		<li class="list-2-item"><a href="../controller/">Controller</a></li>
    		<li class="mob-list-2-prod"><a href="../product-center/">Product center</a></li>
    	</ul>
    	<ul class="soc-1">
    		<li><a class="weechat" href="https://msngr.link/wc/79871170012" target="_blank"><img src="/assets/img/icon-weechat.svg" alt="иконка Вичата">WeChat: lihaistas</a></li>
    		<li><a href="https://api.whatsapp.com/send?phone=8613632527554" target="_blank"><img src="/assets/img/icon-whatsapp.svg" alt="иконка WhatsApp">WhatsApp: +8613632527554</a></li>
    	</ul>
    	<!--<ul class="soc-2">
    		<li><a href="https://www.facebook.com/greentest.official" target="_blank"><img src="/assets/img/icon-facebook.svg" alt="иконка Facebook">Facebook</a></li>
    		<li><a href="https://www.youtube.com/channel/UCisopLJJey-qrG2k5Qy3iAg" target="_blank"><img src="/assets/img/icon-youtube.svg" alt="иконка YouTube">You Tube</a></li>
    		<li><a href="https://www.instagram.com/greentest.official" target="_blank"><img src="/assets/img/icon-instagram.svg" alt="иконка Instagram">Instagram</a></li>
    	</ul>-->
    </div>
</div>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'bottom-footer' => 
      array (
        'fields' => 
        array (
          'id' => 13,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'bottom-footer',
          'description' => 'нижняя часть футера',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<div class="footer-bottom-wrapper">
	<p class="footer-text">&#169; <!-- Знак копирайта-->
		<script>document.write(new Date().getFullYear());</script><!-- Автоизменение года-->
		 Greennovo Science & Technology Co., LTD</p>
</div>
<div id="cookie_notification"><!-- Куки-->
	<p>By using the greennovo.pro website, I consent to the processing of my personal data using cookies and third-party services and accept the terms of the <a href="../privacy-policy.html">Privacy Policy</a></p>
	<button class="button cookie_accept">Accept</button>
</div>
',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<div class="footer-bottom-wrapper">
	<p class="footer-text">&#169; <!-- Знак копирайта-->
		<script>document.write(new Date().getFullYear());</script><!-- Автоизменение года-->
		 Greennovo Science & Technology Co., LTD</p>
</div>
<div id="cookie_notification"><!-- Куки-->
	<p>By using the greennovo.pro website, I consent to the processing of my personal data using cookies and third-party services and accept the terms of the <a href="../privacy-policy.html">Privacy Policy</a></p>
	<button class="button cookie_accept">Accept</button>
</div>
',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'arrow-top' => 
      array (
        'fields' => 
        array (
          'id' => 14,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'arrow-top',
          'description' => 'стрелка наверх',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<a class="back-to-top" title="Наверх">
	<img src="/assets/img/angle-up.svg" alt="иконка Наверх">
</a>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<a class="back-to-top" title="Наверх">
	<img src="/assets/img/angle-up.svg" alt="иконка Наверх">
</a>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'scripts' => 
      array (
        'fields' => 
        array (
          'id' => 15,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'scripts',
          'description' => 'подключение скриптов',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<!--Подключение библиотеки jQuery-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<!-- СКРИПТЫ -->
<script src="/assets/scripts.js"></script>
<script src="/assets/animation.js"></script><!-- Плавная загрузка блоков --> 
<script src="/assets/language.js"></script>
<!-- Свайпер -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<!--Подключение библиотеки jQuery-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<!-- СКРИПТЫ -->
<script src="/assets/scripts.js"></script>
<script src="/assets/animation.js"></script><!-- Плавная загрузка блоков --> 
<script src="/assets/language.js"></script>
<!-- Свайпер -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'swiper' => 
      array (
        'fields' => 
        array (
          'id' => 27,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'swiper',
          'description' => 'Слайдер',
          'editor_type' => 0,
          'category' => 1,
          'cache_type' => 0,
          'snippet' => '<script type="text/javascript">
    //Свайпер
    let swiper = new Swiper(\'.swiper\', {
        
    	autoplay: {
    		delay: 4000,
    		disableOnInteraction: false, //остановка после ручной прокрутки
    	},
    
    	loop: true, //бесконечная прокрутка
    
    	speed: 1500, //скорость
    
    	keyboard: { //управление с клавы
    		enabled: true,
    		onlyInViewport: true,
    		pageUpDown: true,
    	},
    
    	effect: \'fade\', //Эффект появления
    		/*creativeEffect: {
    			prev: {
    				// will set `translateZ(-400px)` on previous slides
    				translate: [0, 0, -300],
    			},
    			next: {
    				// will set `translateX(100%)` on next slides
    				translate: [\'100%\', 0, 0],
    			},
    	},*/
    
    	//autoHeight: true, //автовысота
    	
/*lazy: { // поочередная загрузка картинок
	loadOnTransitionStart: false,
	loadPrevNext: false,
	},
preloadImages: true,*/
    
//parallax: true,
//grabCursor: true,
//slideToClickedSlide: true,
    });
</script>',
          'locked' => false,
          'properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '<script type="text/javascript">
    //Свайпер
    let swiper = new Swiper(\'.swiper\', {
        
    	autoplay: {
    		delay: 4000,
    		disableOnInteraction: false, //остановка после ручной прокрутки
    	},
    
    	loop: true, //бесконечная прокрутка
    
    	speed: 1500, //скорость
    
    	keyboard: { //управление с клавы
    		enabled: true,
    		onlyInViewport: true,
    		pageUpDown: true,
    	},
    
    	effect: \'fade\', //Эффект появления
    		/*creativeEffect: {
    			prev: {
    				// will set `translateZ(-400px)` on previous slides
    				translate: [0, 0, -300],
    			},
    			next: {
    				// will set `translateX(100%)` on next slides
    				translate: [\'100%\', 0, 0],
    			},
    	},*/
    
    	//autoHeight: true, //автовысота
    	
/*lazy: { // поочередная загрузка картинок
	loadOnTransitionStart: false,
	loadPrevNext: false,
	},
preloadImages: true,*/
    
//parallax: true,
//grabCursor: true,
//slideToClickedSlide: true,
    });
</script>',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modSnippet' => 
    array (
      'pdoMenu' => 
      array (
        'fields' => 
        array (
          'id' => 17,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'pdoMenu',
          'description' => '',
          'editor_type' => 0,
          'category' => 10,
          'cache_type' => 0,
          'snippet' => '/** @var array $scriptProperties */
/** @var modX $modx */

// Convert parameters from Wayfinder if exists
if (isset($startId)) {
    $scriptProperties[\'parents\'] = $startId;
}
if (!empty($includeDocs)) {
    $tmp = array_map(\'trim\', explode(\',\', $includeDocs));
    foreach ($tmp as $v) {
        if (!empty($scriptProperties[\'resources\'])) {
            $scriptProperties[\'resources\'] .= \',\' . $v;
        } else {
            $scriptProperties[\'resources\'] = $v;
        }
    }
}
if (!empty($excludeDocs)) {
    $tmp = array_map(\'trim\', explode(\',\', $excludeDocs));
    foreach ($tmp as $v) {
        if (!empty($scriptProperties[\'resources\'])) {
            $scriptProperties[\'resources\'] .= \',-\' . $v;
        } else {
            $scriptProperties[\'resources\'] = \'-\' . $v;
        }
    }
}

if (!empty($previewUnpublished) && $modx->hasPermission(\'view_unpublished\')) {
    $scriptProperties[\'showUnpublished\'] = 1;
}

$scriptProperties[\'depth\'] = empty($level) ? 100 : abs($level) - 1;
if (!empty($contexts)) {
    $scriptProperties[\'context\'] = $contexts;
}
if (empty($scriptProperties[\'context\'])) {
    $scriptProperties[\'context\'] = $modx->resource->context_key;
}

// Save original parents specified by user
$specified_parents = array_map(\'trim\', explode(\',\', $scriptProperties[\'parents\']));

if ($scriptProperties[\'parents\'] === \'\') {
    $scriptProperties[\'parents\'] = $modx->resource->id;
} elseif ($scriptProperties[\'parents\'] === 0 || $scriptProperties[\'parents\'] === \'0\') {
    if ($scriptProperties[\'depth\'] !== \'\' && $scriptProperties[\'depth\'] !== 100) {
        $contexts = array_map(\'trim\', explode(\',\', $scriptProperties[\'context\']));
        $parents = array();
        if (!empty($scriptProperties[\'showDeleted\'])) {
            /** @var pdoFetch $pdoFetch */
            $pdoFetch = $modx->getService(\'pdoFetch\');
            foreach ($contexts as $ctx) {
                $parents = array_merge($parents, $pdoFetch->getChildIds(\'modResource\', 0, $scriptProperties[\'depth\'], array(\'context\' => $ctx)));
            }
        } else {
            foreach ($contexts as $ctx) {
                $parents = array_merge($parents, $modx->getChildIds(0, $scriptProperties[\'depth\'], array(\'context\' => $ctx)));
            }
        }
        $scriptProperties[\'parents\'] = !empty($parents) ? implode(\',\', $parents) : \'+0\';
        $scriptProperties[\'depth\'] = 0;
    }
    $scriptProperties[\'includeParents\'] = 1;
    $scriptProperties[\'displayStart\'] = 0;
} else {
    $parents = array_map(\'trim\', explode(\',\', $scriptProperties[\'parents\']));
    $parents_in = $parents_out = array();
    foreach ($parents as $v) {
        if (!is_numeric($v)) {
            continue;
        }
        if ($v[0] == \'-\') {
            $parents_out[] = abs($v);
        } else {
            $parents_in[] = abs($v);
        }
    }

    if (empty($parents_in)) {
        $scriptProperties[\'includeParents\'] = 1;
        $scriptProperties[\'displayStart\'] = 0;
    }
}

if (!empty($displayStart)) {
    $scriptProperties[\'includeParents\'] = 1;
}
if (!empty($ph)) {
    $toPlaceholder = $ph;
}
if (!empty($sortOrder)) {
    $scriptProperties[\'sortdir\'] = $sortOrder;
}
if (!empty($sortBy)) {
    $scriptProperties[\'sortby\'] = $sortBy;
}
if (!empty($permissions)) {
    $scriptProperties[\'checkPermissions\'] = $permissions;
}
if (!empty($cacheResults)) {
    $scriptProperties[\'cache\'] = $cacheResults;
}
if (!empty($ignoreHidden)) {
    $scriptProperties[\'showHidden\'] = $ignoreHidden;
}

$wfTemplates = array(
    \'outerTpl\' => \'tplOuter\',
    \'rowTpl\' => \'tpl\',
    \'parentRowTpl\' => \'tplParentRow\',
    \'parentRowHereTpl\' => \'tplParentRowHere\',
    \'hereTpl\' => \'tplHere\',
    \'innerTpl\' => \'tplInner\',
    \'innerRowTpl\' => \'tplInnerRow\',
    \'innerHereTpl\' => \'tplInnerHere\',
    \'activeParentRowTpl\' => \'tplParentRowActive\',
    \'categoryFoldersTpl\' => \'tplCategoryFolder\',
    \'startItemTpl\' => \'tplStart\',
);
foreach ($wfTemplates as $k => $v) {
    if (isset(${$k})) {
        $scriptProperties[$v] = ${$k};
    }
}
//---

/** @var pdoMenu $pdoMenu */
$fqn = $modx->getOption(\'pdoMenu.class\', null, \'pdotools.pdomenu\', true);
$path = $modx->getOption(\'pdomenu_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);
if ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {
    $pdoMenu = new $pdoClass($modx, $scriptProperties);
} else {
    return false;
}
$pdoMenu->pdoTools->addTime(\'pdoTools loaded\');

$cache = !empty($cache) || (!$modx->user->id && !empty($cacheAnonymous));
if (empty($scriptProperties[\'cache_key\'])) {
    $scriptProperties[\'cache_key\'] = \'pdomenu/\' . sha1(serialize($scriptProperties));
}

$output = \'\';
$tree = array();
if ($cache) {
    $tree = $pdoMenu->pdoTools->getCache($scriptProperties);
}
if (empty($tree)) {
    $data = $pdoMenu->pdoTools->run();
    $data = $pdoMenu->pdoTools->buildTree($data, \'id\', \'parent\', $specified_parents);
    $tree = array();
    foreach ($data as $k => $v) {
        if (empty($v[\'id\'])) {
            if (!in_array($k, $specified_parents) && !$pdoMenu->checkResource($k)) {
                continue;
            } else {
                $tree = array_merge($tree, $v[\'children\']);
            }
        } else {
            $tree[$k] = $v;
        }
    }
    if ($cache) {
        $pdoMenu->pdoTools->setCache($tree, $scriptProperties);
    }
}
if (isset($return) && $return === \'data\') {
    return $tree;
}
if (!empty($tree)) {
    $output = $pdoMenu->templateTree($tree);
}

if ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {
    $output .= \'<pre class="pdoMenuLog">\' . print_r($pdoMenu->pdoTools->getTime(), 1) . \'</pre>\';
}

if (!empty($toPlaceholder)) {
    $modx->setPlaceholder($toPlaceholder, $output);
} else {
    return $output;
}',
          'locked' => false,
          'properties' => 
          array (
            'showLog' => 
            array (
              'name' => 'showLog',
              'desc' => 'pdotools_prop_showLog',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, snippet will add detailed log of query for developers.',
              'area_trans' => '',
            ),
            'fastMode' => 
            array (
              'name' => 'fastMode',
              'desc' => 'pdotools_prop_fastMode',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Fast chunks processing. If true, MODX parser will not be used and unprocessed tags will be cut.',
              'area_trans' => '',
            ),
            'level' => 
            array (
              'name' => 'level',
              'desc' => 'pdotools_prop_level',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => 0,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Depth (number of levels) to build the menu from. 0 goes through all levels.',
              'area_trans' => '',
            ),
            'parents' => 
            array (
              'name' => 'parents',
              'desc' => 'pdotools_prop_parents',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-delimited list of ids serving as parents. Use "0" to ignore parents when specifying resources to include. Prefix an id of parent with a dash to exclude it and its children from the result.',
              'area_trans' => '',
            ),
            'displayStart' => 
            array (
              'name' => 'displayStart',
              'desc' => 'pdotools_prop_displayStart',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Show the document as referenced by startId in the menu.',
              'area_trans' => '',
            ),
            'resources' => 
            array (
              'name' => 'resources',
              'desc' => 'pdotools_prop_resources',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-delimited list of ids to include in the results. Prefix an id with a dash to exclude the resource from the result.',
              'area_trans' => '',
            ),
            'templates' => 
            array (
              'name' => 'templates',
              'desc' => 'pdotools_prop_templates',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-delimited list of templates to filter the results. Prefix an id of template with a dash to exclude the resource with it from the result.',
              'area_trans' => '',
            ),
            'context' => 
            array (
              'name' => 'context',
              'desc' => 'pdotools_prop_context',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Which Context should be searched in.',
              'area_trans' => '',
            ),
            'cache' => 
            array (
              'name' => 'cache',
              'desc' => 'pdotools_prop_cache',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Caching the results of the snippet.',
              'area_trans' => '',
            ),
            'cacheTime' => 
            array (
              'name' => 'cacheTime',
              'desc' => 'pdotools_prop_cacheTime',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => 3600,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Time until the cache expires, in seconds.',
              'area_trans' => '',
            ),
            'cacheAnonymous' => 
            array (
              'name' => 'cacheAnonymous',
              'desc' => 'pdotools_prop_cacheAnonymous',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Enable caching only for unauthorized visitors.',
              'area_trans' => '',
            ),
            'plPrefix' => 
            array (
              'name' => 'plPrefix',
              'desc' => 'pdotools_prop_plPrefix',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'wf.',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Prefix for output placeholders, by default is "wf.".',
              'area_trans' => '',
            ),
            'showHidden' => 
            array (
              'name' => 'showHidden',
              'desc' => 'pdotools_prop_showHidden',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, will show Resources regardless if they are hidden from the menus.',
              'area_trans' => '',
            ),
            'showUnpublished' => 
            array (
              'name' => 'showUnpublished',
              'desc' => 'pdotools_prop_showUnpublished',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, will also show Resources regardless if they are unpublished.',
              'area_trans' => '',
            ),
            'showDeleted' => 
            array (
              'name' => 'showDeleted',
              'desc' => 'pdotools_prop_showDeleted',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, will show Resources regardless if they are deleted.',
              'area_trans' => '',
            ),
            'previewUnpublished' => 
            array (
              'name' => 'previewUnpublished',
              'desc' => 'pdotools_prop_previewUnpublished',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Optional. If set to Yes, if you are logged into the mgr and have the view_unpublished permission, it will allow previewing of unpublished resources in your menus in the front-end.',
              'area_trans' => '',
            ),
            'hideSubMenus' => 
            array (
              'name' => 'hideSubMenus',
              'desc' => 'pdotools_prop_hideSubMenus',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'The hideSubMenus parameter will remove all non-active submenus from the script output if set to 1. This parameter only works if multiple levels are being displayed.',
              'area_trans' => '',
            ),
            'useWeblinkUrl' => 
            array (
              'name' => 'useWeblinkUrl',
              'desc' => 'pdotools_prop_useWeblinkUrl',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => true,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If WebLinks are used in the output, script will output the link specified in the WebLink instead of the normal MODX link. To use the standard display of WebLinks (like any other Resource) set this to 0.',
              'area_trans' => '',
            ),
            'sortdir' => 
            array (
              'name' => 'sortdir',
              'desc' => 'pdotools_prop_sortdir',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'text' => 'ASC',
                  'value' => 'ASC',
                  'name' => 'ASC',
                ),
                1 => 
                array (
                  'text' => 'DESC',
                  'value' => 'DESC',
                  'name' => 'DESC',
                ),
              ),
              'value' => 'ASC',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Order which to sort by: descending or ascending',
              'area_trans' => '',
            ),
            'sortby' => 
            array (
              'name' => 'sortby',
              'desc' => 'pdotools_prop_sortby',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'menuindex',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Any Resource Field (including Template Variables if they have been included) to sort by. Some common fields to sort on are publishedon, menuindex, pagetitle etc., but see the Resources documentation for all fields. Specify fields with the name only, not using the tag syntax. Note that when using fields like template, publishedby and the likes for sorting, it will be sorted on the raw values, so the template or user ID, and NOT their names. You can also sort randomly by specifying RAND().',
              'area_trans' => '',
            ),
            'limit' => 
            array (
              'name' => 'limit',
              'desc' => 'pdotools_prop_limit',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => 0,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Limits the number of resources returned.  Use "0" for unlimited results.',
              'area_trans' => '',
            ),
            'offset' => 
            array (
              'name' => 'offset',
              'desc' => 'pdotools_prop_offset',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => 0,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'An offset of resources returned by the criteria to skip.',
              'area_trans' => '',
            ),
            'rowIdPrefix' => 
            array (
              'name' => 'rowIdPrefix',
              'desc' => 'pdotools_prop_rowIdPrefix',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If set, script will replace the id placeholder with a unique id consisting of the specified prefix plus the Resource id.',
              'area_trans' => '',
            ),
            'firstClass' => 
            array (
              'name' => 'firstClass',
              'desc' => 'pdotools_prop_firstClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'first',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for the first item at a given menu level.',
              'area_trans' => '',
            ),
            'lastClass' => 
            array (
              'name' => 'lastClass',
              'desc' => 'pdotools_prop_lastClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'last',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for the last item at a given menu level.',
              'area_trans' => '',
            ),
            'hereClass' => 
            array (
              'name' => 'hereClass',
              'desc' => 'pdotools_prop_hereClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'active',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for the items showing where you are, all the way up the chain.',
              'area_trans' => '',
            ),
            'parentClass' => 
            array (
              'name' => 'parentClass',
              'desc' => 'pdotools_prop_parentClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for menu items that are a container and have children.',
              'area_trans' => '',
            ),
            'rowClass' => 
            array (
              'name' => 'rowClass',
              'desc' => 'pdotools_prop_rowClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class denoting each output row.',
              'area_trans' => '',
            ),
            'outerClass' => 
            array (
              'name' => 'outerClass',
              'desc' => 'pdotools_prop_outerClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for the outer template.',
              'area_trans' => '',
            ),
            'innerClass' => 
            array (
              'name' => 'innerClass',
              'desc' => 'pdotools_prop_innerClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for the inner template.',
              'area_trans' => '',
            ),
            'levelClass' => 
            array (
              'name' => 'levelClass',
              'desc' => 'pdotools_prop_levelClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class denoting every output row level. The level number will be added to the specified class (level1, level2, level3 etc. if you specified "level").',
              'area_trans' => '',
            ),
            'selfClass' => 
            array (
              'name' => 'selfClass',
              'desc' => 'pdotools_prop_selfClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for the current item.',
              'area_trans' => '',
            ),
            'webLinkClass' => 
            array (
              'name' => 'webLinkClass',
              'desc' => 'pdotools_prop_webLinkClass',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'CSS class for weblink items.',
              'area_trans' => '',
            ),
            'tplOuter' => 
            array (
              'name' => 'tplOuter',
              'desc' => 'pdotools_prop_tplOuter',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '@INLINE <ul[[+classes]]>[[+wrapper]]</ul>',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for the outer most container; if not included, a string including "&lt;ul&gt;[[+wrapper]]&lt;/ul&gt;" is assumed.',
              'area_trans' => '',
            ),
            'tpl' => 
            array (
              'name' => 'tpl',
              'desc' => 'pdotools_prop_tpl',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '@INLINE <li[[+classes]]><a href="[[+link]]" [[+attributes]]>[[+menutitle]]</a>[[+wrapper]]</li>',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of a chunk serving as a resource template. If not provided, properties are dumped to output for each resource.',
              'area_trans' => '',
            ),
            'tplParentRow' => 
            array (
              'name' => 'tplParentRow',
              'desc' => 'pdotools_prop_tplParentRow',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for any Resource that is a container and has children. Remember the [[+wrapper]] placeholder to output the children documents.',
              'area_trans' => '',
            ),
            'tplParentRowHere' => 
            array (
              'name' => 'tplParentRowHere',
              'desc' => 'pdotools_prop_tplParentRowHere',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for the current Resource if it is a container and has children. Remember the [[+wf.wrapper]] placeholder to output the children documents.',
              'area_trans' => '',
            ),
            'tplHere' => 
            array (
              'name' => 'tplHere',
              'desc' => 'pdotools_prop_tplHere',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for the current Resource if it is a container and has children. Remember the [[+wf.wrapper]] placeholder to output the children documents.',
              'area_trans' => '',
            ),
            'tplInner' => 
            array (
              'name' => 'tplInner',
              'desc' => 'pdotools_prop_tplInner',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for each submenu. If no innerTpl is specified the outerTpl is used in its place.',
              'area_trans' => '',
            ),
            'tplInnerRow' => 
            array (
              'name' => 'tplInnerRow',
              'desc' => 'pdotools_prop_tplInnerRow',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for the one Resource if it is in a subfolder.',
              'area_trans' => '',
            ),
            'tplInnerHere' => 
            array (
              'name' => 'tplInnerHere',
              'desc' => 'pdotools_prop_tplInnerHere',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for the current Resource if it is in a subfolder.',
              'area_trans' => '',
            ),
            'tplParentRowActive' => 
            array (
              'name' => 'tplParentRowActive',
              'desc' => 'pdotools_prop_tplParentRowActive',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for items that are containers, have children and are currently active in the tree.',
              'area_trans' => '',
            ),
            'tplCategoryFolder' => 
            array (
              'name' => 'tplCategoryFolder',
              'desc' => 'pdotools_prop_tplCategoryFolder',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for the outer most container; if not included, a string including "&lt;ul&gt;[[+wf.wrapper]]&lt;/ul&gt;" is assumed.',
              'area_trans' => '',
            ),
            'tplStart' => 
            array (
              'name' => 'tplStart',
              'desc' => 'pdotools_prop_tplStart',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '@INLINE <h2[[+classes]]>[[+menutitle]]</h2>[[+wrapper]]',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of the chunk containing the template for the start item, if enabled via the &displayStart parameter. Note: the default template shows the start item but does not link it. If you do not need a link, a class can be applied to the default template using the parameter &firstClass=`className`.',
              'area_trans' => '',
            ),
            'checkPermissions' => 
            array (
              'name' => 'checkPermissions',
              'desc' => 'pdotools_prop_checkPermissions',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-separated list of permissions to check when building the menu.',
              'area_trans' => '',
            ),
            'hereId' => 
            array (
              'name' => 'hereId',
              'desc' => 'pdotools_prop_hereId',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Optional. If set, will change the "here" Resource to this ID. Defaults to the currently active Resource.',
              'area_trans' => '',
            ),
            'where' => 
            array (
              'name' => 'where',
              'desc' => 'pdotools_prop_where',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'A JSON-style expression of criteria to build any additional where clauses from.',
              'area_trans' => '',
            ),
            'select' => 
            array (
              'name' => 'select',
              'desc' => 'pdotools_prop_select',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-separated list of columns for select from database. You can specify JSON string with array, for example {"modResource":"id,pagetitle,content"}.',
              'area_trans' => '',
            ),
            'scheme' => 
            array (
              'name' => 'scheme',
              'desc' => 'pdotools_prop_scheme',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'value' => '',
                  'text' => 'System default',
                  'name' => 'System default',
                ),
                1 => 
                array (
                  'value' => -1,
                  'text' => '-1 (relative to site_url)',
                  'name' => '-1 (relative to site_url)',
                ),
                2 => 
                array (
                  'value' => 'full',
                  'text' => 'full (absolute, prepended with site_url)',
                  'name' => 'full (absolute, prepended with site_url)',
                ),
                3 => 
                array (
                  'value' => 'abs',
                  'text' => 'abs (absolute, prepended with base_url)',
                  'name' => 'abs (absolute, prepended with base_url)',
                ),
                4 => 
                array (
                  'value' => 'http',
                  'text' => 'http (absolute, forced to http scheme)',
                  'name' => 'http (absolute, forced to http scheme)',
                ),
                5 => 
                array (
                  'value' => 'https',
                  'text' => 'https (absolute, forced to https scheme)',
                  'name' => 'https (absolute, forced to https scheme)',
                ),
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Scheme of generation of links: "uri" for the substitution of document uri (very fast) or a parameter to modX::makeUrl().',
              'area_trans' => '',
            ),
            'toPlaceholder' => 
            array (
              'name' => 'toPlaceholder',
              'desc' => 'pdotools_prop_toPlaceholder',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If set, will assign the result to this placeholder instead of outputting it directly.',
              'area_trans' => '',
            ),
            'countChildren' => 
            array (
              'name' => 'countChildren',
              'desc' => 'pdotools_prop_countChildren',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Display the exact number of active descendants of the document in placeholder [[+children]].',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => 'core/components/pdotools/elements/snippets/snippet.pdomenu.php',
          'content' => '/** @var array $scriptProperties */
/** @var modX $modx */

// Convert parameters from Wayfinder if exists
if (isset($startId)) {
    $scriptProperties[\'parents\'] = $startId;
}
if (!empty($includeDocs)) {
    $tmp = array_map(\'trim\', explode(\',\', $includeDocs));
    foreach ($tmp as $v) {
        if (!empty($scriptProperties[\'resources\'])) {
            $scriptProperties[\'resources\'] .= \',\' . $v;
        } else {
            $scriptProperties[\'resources\'] = $v;
        }
    }
}
if (!empty($excludeDocs)) {
    $tmp = array_map(\'trim\', explode(\',\', $excludeDocs));
    foreach ($tmp as $v) {
        if (!empty($scriptProperties[\'resources\'])) {
            $scriptProperties[\'resources\'] .= \',-\' . $v;
        } else {
            $scriptProperties[\'resources\'] = \'-\' . $v;
        }
    }
}

if (!empty($previewUnpublished) && $modx->hasPermission(\'view_unpublished\')) {
    $scriptProperties[\'showUnpublished\'] = 1;
}

$scriptProperties[\'depth\'] = empty($level) ? 100 : abs($level) - 1;
if (!empty($contexts)) {
    $scriptProperties[\'context\'] = $contexts;
}
if (empty($scriptProperties[\'context\'])) {
    $scriptProperties[\'context\'] = $modx->resource->context_key;
}

// Save original parents specified by user
$specified_parents = array_map(\'trim\', explode(\',\', $scriptProperties[\'parents\']));

if ($scriptProperties[\'parents\'] === \'\') {
    $scriptProperties[\'parents\'] = $modx->resource->id;
} elseif ($scriptProperties[\'parents\'] === 0 || $scriptProperties[\'parents\'] === \'0\') {
    if ($scriptProperties[\'depth\'] !== \'\' && $scriptProperties[\'depth\'] !== 100) {
        $contexts = array_map(\'trim\', explode(\',\', $scriptProperties[\'context\']));
        $parents = array();
        if (!empty($scriptProperties[\'showDeleted\'])) {
            /** @var pdoFetch $pdoFetch */
            $pdoFetch = $modx->getService(\'pdoFetch\');
            foreach ($contexts as $ctx) {
                $parents = array_merge($parents, $pdoFetch->getChildIds(\'modResource\', 0, $scriptProperties[\'depth\'], array(\'context\' => $ctx)));
            }
        } else {
            foreach ($contexts as $ctx) {
                $parents = array_merge($parents, $modx->getChildIds(0, $scriptProperties[\'depth\'], array(\'context\' => $ctx)));
            }
        }
        $scriptProperties[\'parents\'] = !empty($parents) ? implode(\',\', $parents) : \'+0\';
        $scriptProperties[\'depth\'] = 0;
    }
    $scriptProperties[\'includeParents\'] = 1;
    $scriptProperties[\'displayStart\'] = 0;
} else {
    $parents = array_map(\'trim\', explode(\',\', $scriptProperties[\'parents\']));
    $parents_in = $parents_out = array();
    foreach ($parents as $v) {
        if (!is_numeric($v)) {
            continue;
        }
        if ($v[0] == \'-\') {
            $parents_out[] = abs($v);
        } else {
            $parents_in[] = abs($v);
        }
    }

    if (empty($parents_in)) {
        $scriptProperties[\'includeParents\'] = 1;
        $scriptProperties[\'displayStart\'] = 0;
    }
}

if (!empty($displayStart)) {
    $scriptProperties[\'includeParents\'] = 1;
}
if (!empty($ph)) {
    $toPlaceholder = $ph;
}
if (!empty($sortOrder)) {
    $scriptProperties[\'sortdir\'] = $sortOrder;
}
if (!empty($sortBy)) {
    $scriptProperties[\'sortby\'] = $sortBy;
}
if (!empty($permissions)) {
    $scriptProperties[\'checkPermissions\'] = $permissions;
}
if (!empty($cacheResults)) {
    $scriptProperties[\'cache\'] = $cacheResults;
}
if (!empty($ignoreHidden)) {
    $scriptProperties[\'showHidden\'] = $ignoreHidden;
}

$wfTemplates = array(
    \'outerTpl\' => \'tplOuter\',
    \'rowTpl\' => \'tpl\',
    \'parentRowTpl\' => \'tplParentRow\',
    \'parentRowHereTpl\' => \'tplParentRowHere\',
    \'hereTpl\' => \'tplHere\',
    \'innerTpl\' => \'tplInner\',
    \'innerRowTpl\' => \'tplInnerRow\',
    \'innerHereTpl\' => \'tplInnerHere\',
    \'activeParentRowTpl\' => \'tplParentRowActive\',
    \'categoryFoldersTpl\' => \'tplCategoryFolder\',
    \'startItemTpl\' => \'tplStart\',
);
foreach ($wfTemplates as $k => $v) {
    if (isset(${$k})) {
        $scriptProperties[$v] = ${$k};
    }
}
//---

/** @var pdoMenu $pdoMenu */
$fqn = $modx->getOption(\'pdoMenu.class\', null, \'pdotools.pdomenu\', true);
$path = $modx->getOption(\'pdomenu_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);
if ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {
    $pdoMenu = new $pdoClass($modx, $scriptProperties);
} else {
    return false;
}
$pdoMenu->pdoTools->addTime(\'pdoTools loaded\');

$cache = !empty($cache) || (!$modx->user->id && !empty($cacheAnonymous));
if (empty($scriptProperties[\'cache_key\'])) {
    $scriptProperties[\'cache_key\'] = \'pdomenu/\' . sha1(serialize($scriptProperties));
}

$output = \'\';
$tree = array();
if ($cache) {
    $tree = $pdoMenu->pdoTools->getCache($scriptProperties);
}
if (empty($tree)) {
    $data = $pdoMenu->pdoTools->run();
    $data = $pdoMenu->pdoTools->buildTree($data, \'id\', \'parent\', $specified_parents);
    $tree = array();
    foreach ($data as $k => $v) {
        if (empty($v[\'id\'])) {
            if (!in_array($k, $specified_parents) && !$pdoMenu->checkResource($k)) {
                continue;
            } else {
                $tree = array_merge($tree, $v[\'children\']);
            }
        } else {
            $tree[$k] = $v;
        }
    }
    if ($cache) {
        $pdoMenu->pdoTools->setCache($tree, $scriptProperties);
    }
}
if (isset($return) && $return === \'data\') {
    return $tree;
}
if (!empty($tree)) {
    $output = $pdoMenu->templateTree($tree);
}

if ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {
    $output .= \'<pre class="pdoMenuLog">\' . print_r($pdoMenu->pdoTools->getTime(), 1) . \'</pre>\';
}

if (!empty($toPlaceholder)) {
    $modx->setPlaceholder($toPlaceholder, $output);
} else {
    return $output;
}',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'pdoCrumbs' => 
      array (
        'fields' => 
        array (
          'id' => 12,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'pdoCrumbs',
          'description' => '',
          'editor_type' => 0,
          'category' => 10,
          'cache_type' => 0,
          'snippet' => '/** @var array $scriptProperties */
/** @var pdoFetch $pdoFetch */
/** @var modX $modx */
$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);
$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);
if ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {
    $pdoFetch = new $pdoClass($modx, $scriptProperties);
} else {
    return false;
}
$pdoFetch->addTime(\'pdoTools loaded\');

if (!isset($from) || $from == \'\') {
    $from = 0;
}
if (empty($to)) {
    $to = $modx->resource->id;
}
if (empty($direction)) {
    $direction = \'ltr\';
}
if ($outputSeparator == \'&nbsp;&rarr;&nbsp;\' && $direction == \'rtl\') {
    $outputSeparator = \'&nbsp;&larr;&nbsp;\';
}
if ($limit == \'\') {
    $limit = 10;
}

// For compatibility with BreadCrumb
if (!empty($maxCrumbs)) {
    $limit = $maxCrumbs;
}
if (!empty($containerTpl)) {
    $tplWrapper = $containerTpl;
}
if (!empty($currentCrumbTpl)) {
    $tplCurrent = $currentCrumbTpl;
}
if (!empty($linkCrumbTpl)) {
    $scriptProperties[\'tpl\'] = $linkCrumbTpl;
}
if (!empty($maxCrumbTpl)) {
    $tplMax = $maxCrumbTpl;
}
if (isset($showBreadCrumbsAtHome)) {
    $showAtHome = $showBreadCrumbsAtHome;
}
if (isset($showHomeCrumb)) {
    $showHome = $showHomeCrumb;
}
if (isset($showCurrentCrumb)) {
    $showCurrent = $showCurrentCrumb;
}
// --
$fastMode = !empty($fastMode);
$siteStart = $modx->getOption(\'siteStart\', $scriptProperties, $modx->getOption(\'site_start\'));

if (empty($showAtHome) && $modx->resource->id == $siteStart) {
    return \'\';
}

$class = $modx->getOption(\'class\', $scriptProperties, \'modResource\');
// Start building "Where" expression
$where = array();
if (empty($showUnpublished) && empty($showUnPub)) {
    $where[\'published\'] = 1;
}
if (empty($showHidden)) {
    $where[\'hidemenu\'] = 0;
}
if (empty($showDeleted)) {
    $where[\'deleted\'] = 0;
}
if (!empty($hideContainers) && empty($showContainer)) {
    $where[\'isfolder\'] = 0;
}

$resource = ($to == $modx->resource->id)
    ? $modx->resource
    : $modx->getObject($class, $to);

if (!$resource) {
    $message = \'Could not build breadcrumbs to resource "\' . $to . \'"\';

    return \'\';
}

if (!empty($customParents)) {
    $customParents = is_array($customParents) ? $customParents : array_map(\'trim\', explode(\',\', $customParents));
    $parents = is_array($customParents) ? array_reverse($customParents) : array();
}
if (empty($parents)) {
    $parents = $modx->getParentIds($resource->id, $limit, array(\'context\' => $resource->get(\'context_key\')));
}
if (!empty($showHome)) {
    $parents[] = $siteStart;
}

$ids = array($resource->id);
foreach ($parents as $parent) {
    if (!empty($parent)) {
        $ids[] = $parent;
    }
    if (!empty($from) && $parent == $from) {
        break;
    }
}
$where[\'id:IN\'] = $ids;

if (!empty($exclude)) {
    $where[\'id:NOT IN\'] = array_map(\'trim\', explode(\',\', $exclude));
}

// Fields to select
$resourceColumns = array_keys($modx->getFieldMeta($class));
$select = array($class => implode(\',\', $resourceColumns));

// Add custom parameters
foreach (array(\'where\', \'select\') as $v) {
    if (!empty($scriptProperties[$v])) {
        $tmp = $scriptProperties[$v];
        if (!is_array($tmp)) {
            $tmp = json_decode($tmp, true);
        }
        if (is_array($tmp)) {
            $$v = array_merge($$v, $tmp);
        }
    }
    unset($scriptProperties[$v]);
}
$pdoFetch->addTime(\'Conditions prepared\');

// Default parameters
$default = array(
    \'class\' => $class,
    \'where\' => json_encode($where),
    \'select\' => json_encode($select),
    \'groupby\' => $class . \'.id\',
    \'sortby\' => "find_in_set(`$class`.`id`,\'" . implode(\',\', $ids) . "\')",
    \'sortdir\' => \'\',
    \'return\' => \'data\',
    \'totalVar\' => \'pdocrumbs.total\',
    \'disableConditions\' => true,
);

// Merge all properties and run!
$pdoFetch->addTime(\'Query parameters ready\');
$pdoFetch->setConfig(array_merge($default, $scriptProperties), false);
$rows = $pdoFetch->run();

$output = [];
if (!empty($rows) && is_array($rows)) {
    if (strtolower($direction) == \'ltr\') {
        $rows = array_reverse($rows);
    }

    foreach ($rows as $row) {
        if (!empty($useWeblinkUrl) && $row[\'class_key\'] == \'modWebLink\') {
            $row[\'link\'] = is_numeric(trim($row[\'content\'], \'[]~ \'))
                ? $pdoFetch->makeUrl((int)trim($row[\'content\'], \'[]~ \'), $row)
                : $row[\'content\'];
        } else {
            $row[\'link\'] = $pdoFetch->makeUrl($row[\'id\'], $row);
        }

        $row = array_merge(
            $scriptProperties,
            $row,
            [\'idx\' => $pdoFetch->idx++]
        );
        if (empty($row[\'menutitle\'])) {
            $row[\'menutitle\'] = $row[\'pagetitle\'];
        }

        if (isset($return) && $return === \'data\') {
            $output[] = $row;
            continue;
        }
        if ($row[\'id\'] == $resource->id && empty($showCurrent)) {
            continue;
        } elseif ($row[\'id\'] == $resource->id && !empty($tplCurrent)) {
            $tpl = $tplCurrent;
        } elseif ($row[\'id\'] == $siteStart && !empty($tplHome)) {
            $tpl = $tplHome;
        } else {
            $tpl = $pdoFetch->defineChunk($row);
        }
        $output[] = empty($tpl)
            ? \'<pre>\' . $pdoFetch->getChunk(\'\', $row) . \'</pre>\'
            : $pdoFetch->getChunk($tpl, $row, $fastMode);
    }
}
if (isset($return) && $return === \'data\') {
    return $output;
}

$pdoFetch->addTime(\'Chunks processed\');

if (count($output) == 1 && !empty($hideSingle)) {
    $pdoFetch->addTime(\'The only result was hidden, because the parameter "hideSingle" activated\');
    $output = array();
}

$log = \'\';
if ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {
    $log .= \'<pre class="pdoCrumbsLog">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';
}

if (!empty($toSeparatePlaceholders)) {
    $output[\'log\'] = $log;
    $modx->setPlaceholders($output, $toSeparatePlaceholders);
} else {
    $output = implode($outputSeparator, $output);
    if ($pdoFetch->idx >= $limit && !empty($tplMax) && !empty($output)) {
        $output = ($direction == \'ltr\')
            ? $pdoFetch->getChunk($tplMax, array(), $fastMode) . $output
            : $output . $pdoFetch->getChunk($tplMax, array(), $fastMode);
    }
    $output .= $log;

    if (!empty($tplWrapper) && (!empty($wrapIfEmpty) || !empty($output))) {
        $output = $pdoFetch->getChunk($tplWrapper, array(\'output\' => $output, \'crumbs\' => $output), $fastMode);
    }

    if (!empty($toPlaceholder)) {
        $modx->setPlaceholder($toPlaceholder, $output);
    } else {
        return $output;
    }
}',
          'locked' => false,
          'properties' => 
          array (
            'showLog' => 
            array (
              'name' => 'showLog',
              'desc' => 'pdotools_prop_showLog',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, snippet will add detailed log of query for developers.',
              'area_trans' => '',
            ),
            'fastMode' => 
            array (
              'name' => 'fastMode',
              'desc' => 'pdotools_prop_fastMode',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Fast chunks processing. If true, MODX parser will not be used and unprocessed tags will be cut.',
              'area_trans' => '',
            ),
            'from' => 
            array (
              'name' => 'from',
              'desc' => 'pdotools_prop_from',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => 0,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Resource id from which breadcrumb is created. Usually it is root of site, e.g. "0".',
              'area_trans' => '',
            ),
            'to' => 
            array (
              'name' => 'to',
              'desc' => 'pdotools_prop_to',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Resource id whose breadcrumb is created. By default it is id of the current resource.',
              'area_trans' => '',
            ),
            'customParents' => 
            array (
              'name' => 'customParents',
              'desc' => 'pdotools_prop_customParents',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'A comma-separated list of id\'s for custom breadcrumbs construction.',
              'area_trans' => '',
            ),
            'limit' => 
            array (
              'name' => 'limit',
              'desc' => 'pdotools_prop_limit',
              'type' => 'numberfield',
              'options' => 
              array (
              ),
              'value' => 10,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Limits the number of resources returned.  Use "0" for unlimited results.',
              'area_trans' => '',
            ),
            'exclude' => 
            array (
              'name' => 'exclude',
              'desc' => 'pdotools_prop_exclude',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-separated list of resource ids that need to be excluded from the query.',
              'area_trans' => '',
            ),
            'outputSeparator' => 
            array (
              'name' => 'outputSeparator',
              'desc' => 'pdotools_prop_outputSeparator',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '
',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'An optional string to separate each tpl instance.',
              'area_trans' => '',
            ),
            'toPlaceholder' => 
            array (
              'name' => 'toPlaceholder',
              'desc' => 'pdotools_prop_toPlaceholder',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If set, will assign the result to this placeholder instead of outputting it directly.',
              'area_trans' => '',
            ),
            'includeTVs' => 
            array (
              'name' => 'includeTVs',
              'desc' => 'pdotools_prop_includeTVs',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'An optional comma-delimited list of TemplateVar names to include.',
              'area_trans' => '',
            ),
            'prepareTVs' => 
            array (
              'name' => 'prepareTVs',
              'desc' => 'pdotools_prop_prepareTVs',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '1',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-separated list of TV names that need to be prepared. By default it is set to "1", so all TVs in "&includeTVs=``" will be prepared.',
              'area_trans' => '',
            ),
            'processTVs' => 
            array (
              'name' => 'processTVs',
              'desc' => 'pdotools_prop_processTVs',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Comma-separated list of TV names that need to be processed. If you set it to "1" - all TVs in "&includeTVs=``" will be processed. By default it is empty.',
              'area_trans' => '',
            ),
            'tvPrefix' => 
            array (
              'name' => 'tvPrefix',
              'desc' => 'pdotools_prop_tvPrefix',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'tv.',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'The prefix for TemplateVar properties.',
              'area_trans' => '',
            ),
            'where' => 
            array (
              'name' => 'where',
              'desc' => 'pdotools_prop_where',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'A JSON-style expression of criteria to build any additional where clauses from.',
              'area_trans' => '',
            ),
            'showUnpublished' => 
            array (
              'name' => 'showUnpublished',
              'desc' => 'pdotools_prop_showUnpublished',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, will also show Resources regardless if they are unpublished.',
              'area_trans' => '',
            ),
            'showDeleted' => 
            array (
              'name' => 'showDeleted',
              'desc' => 'pdotools_prop_showDeleted',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, will show Resources regardless if they are deleted.',
              'area_trans' => '',
            ),
            'showHidden' => 
            array (
              'name' => 'showHidden',
              'desc' => 'pdotools_prop_showHidden',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => true,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, will show Resources regardless if they are hidden from the menus.',
              'area_trans' => '',
            ),
            'hideContainers' => 
            array (
              'name' => 'hideContainers',
              'desc' => 'pdotools_prop_hideContainers',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If set, will not show any Resources marked as a container (isfolder).',
              'area_trans' => '',
            ),
            'tpl' => 
            array (
              'name' => 'tpl',
              'desc' => 'pdotools_prop_tpl',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '@INLINE <li class="breadcrumb-item"><a href="[[+link]]">[[+menutitle]]</a></li>',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of a chunk serving as a resource template. If not provided, properties are dumped to output for each resource.',
              'area_trans' => '',
            ),
            'tplCurrent' => 
            array (
              'name' => 'tplCurrent',
              'desc' => 'pdotools_prop_tplCurrent',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '@INLINE <li class="breadcrumb-item active">[[+menutitle]]</li>',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Сhunk of the current document in navigation.',
              'area_trans' => '',
            ),
            'tplMax' => 
            array (
              'name' => 'tplMax',
              'desc' => 'pdotools_prop_tplMax',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '@INLINE <li class="breadcrumb-item disabled">&nbsp;...&nbsp;</li>',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Сhunk which is added to the beginning of the results if there are more items than allowed by "&limit".',
              'area_trans' => '',
            ),
            'tplHome' => 
            array (
              'name' => 'tplHome',
              'desc' => 'pdotools_prop_tplHome',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Сhunk of the link to the main page.',
              'area_trans' => '',
            ),
            'tplWrapper' => 
            array (
              'name' => 'tplWrapper',
              'desc' => 'pdotools_prop_tplWrapper',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '@INLINE <ol class="breadcrumb">[[+output]]</ol>',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Name of a chunk serving as a wrapper template for the output. This does not work with toSeparatePlaceholders.',
              'area_trans' => '',
            ),
            'wrapIfEmpty' => 
            array (
              'name' => 'wrapIfEmpty',
              'desc' => 'pdotools_prop_wrapIfEmpty',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If true, will output the wrapper specified in &tplWrapper even if the output is empty.',
              'area_trans' => '',
            ),
            'showCurrent' => 
            array (
              'name' => 'showCurrent',
              'desc' => 'pdotools_prop_showCurrent',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => true,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Display the current document in the navigation.',
              'area_trans' => '',
            ),
            'showHome' => 
            array (
              'name' => 'showHome',
              'desc' => 'pdotools_prop_showHome',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Display a link to the main at the beginning of navigation.',
              'area_trans' => '',
            ),
            'showAtHome' => 
            array (
              'name' => 'showAtHome',
              'desc' => 'pdotools_prop_showAtHome',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => true,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Show bread crumbs on the main page.',
              'area_trans' => '',
            ),
            'hideSingle' => 
            array (
              'name' => 'hideSingle',
              'desc' => 'pdotools_prop_hideSingle',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => false,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Do not display the result if it consists of only one item.',
              'area_trans' => '',
            ),
            'direction' => 
            array (
              'name' => 'direction',
              'desc' => 'pdotools_prop_direction',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'value' => 'ltr',
                  'text' => 'Left To Right (ltr)',
                  'name' => 'Left To Right (ltr)',
                ),
                1 => 
                array (
                  'value' => 'rtl',
                  'text' => 'Right To Left (rtl)',
                  'name' => 'Right To Left (rtl)',
                ),
              ),
              'value' => 'ltr',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Direction or breadcrumb: Left To Right (ltr) or Right To Left (rtl) for Arabic language for example.',
              'area_trans' => '',
            ),
            'scheme' => 
            array (
              'name' => 'scheme',
              'desc' => 'pdotools_prop_scheme',
              'type' => 'list',
              'options' => 
              array (
                0 => 
                array (
                  'value' => '',
                  'text' => 'System default',
                  'name' => 'System default',
                ),
                1 => 
                array (
                  'value' => -1,
                  'text' => '-1 (relative to site_url)',
                  'name' => '-1 (relative to site_url)',
                ),
                2 => 
                array (
                  'value' => 'full',
                  'text' => 'full (absolute, prepended with site_url)',
                  'name' => 'full (absolute, prepended with site_url)',
                ),
                3 => 
                array (
                  'value' => 'abs',
                  'text' => 'abs (absolute, prepended with base_url)',
                  'name' => 'abs (absolute, prepended with base_url)',
                ),
                4 => 
                array (
                  'value' => 'http',
                  'text' => 'http (absolute, forced to http scheme)',
                  'name' => 'http (absolute, forced to http scheme)',
                ),
                5 => 
                array (
                  'value' => 'https',
                  'text' => 'https (absolute, forced to https scheme)',
                  'name' => 'https (absolute, forced to https scheme)',
                ),
              ),
              'value' => '',
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'Scheme of generation of links: "uri" for the substitution of document uri (very fast) or a parameter to modX::makeUrl().',
              'area_trans' => '',
            ),
            'useWeblinkUrl' => 
            array (
              'name' => 'useWeblinkUrl',
              'desc' => 'pdotools_prop_useWeblinkUrl',
              'type' => 'combo-boolean',
              'options' => 
              array (
              ),
              'value' => true,
              'lexicon' => 'pdotools:properties',
              'area' => '',
              'desc_trans' => 'If WebLinks are used in the output, script will output the link specified in the WebLink instead of the normal MODX link. To use the standard display of WebLinks (like any other Resource) set this to 0.',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => 'core/components/pdotools/elements/snippets/snippet.pdocrumbs.php',
          'content' => '/** @var array $scriptProperties */
/** @var pdoFetch $pdoFetch */
/** @var modX $modx */
$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);
$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);
if ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {
    $pdoFetch = new $pdoClass($modx, $scriptProperties);
} else {
    return false;
}
$pdoFetch->addTime(\'pdoTools loaded\');

if (!isset($from) || $from == \'\') {
    $from = 0;
}
if (empty($to)) {
    $to = $modx->resource->id;
}
if (empty($direction)) {
    $direction = \'ltr\';
}
if ($outputSeparator == \'&nbsp;&rarr;&nbsp;\' && $direction == \'rtl\') {
    $outputSeparator = \'&nbsp;&larr;&nbsp;\';
}
if ($limit == \'\') {
    $limit = 10;
}

// For compatibility with BreadCrumb
if (!empty($maxCrumbs)) {
    $limit = $maxCrumbs;
}
if (!empty($containerTpl)) {
    $tplWrapper = $containerTpl;
}
if (!empty($currentCrumbTpl)) {
    $tplCurrent = $currentCrumbTpl;
}
if (!empty($linkCrumbTpl)) {
    $scriptProperties[\'tpl\'] = $linkCrumbTpl;
}
if (!empty($maxCrumbTpl)) {
    $tplMax = $maxCrumbTpl;
}
if (isset($showBreadCrumbsAtHome)) {
    $showAtHome = $showBreadCrumbsAtHome;
}
if (isset($showHomeCrumb)) {
    $showHome = $showHomeCrumb;
}
if (isset($showCurrentCrumb)) {
    $showCurrent = $showCurrentCrumb;
}
// --
$fastMode = !empty($fastMode);
$siteStart = $modx->getOption(\'siteStart\', $scriptProperties, $modx->getOption(\'site_start\'));

if (empty($showAtHome) && $modx->resource->id == $siteStart) {
    return \'\';
}

$class = $modx->getOption(\'class\', $scriptProperties, \'modResource\');
// Start building "Where" expression
$where = array();
if (empty($showUnpublished) && empty($showUnPub)) {
    $where[\'published\'] = 1;
}
if (empty($showHidden)) {
    $where[\'hidemenu\'] = 0;
}
if (empty($showDeleted)) {
    $where[\'deleted\'] = 0;
}
if (!empty($hideContainers) && empty($showContainer)) {
    $where[\'isfolder\'] = 0;
}

$resource = ($to == $modx->resource->id)
    ? $modx->resource
    : $modx->getObject($class, $to);

if (!$resource) {
    $message = \'Could not build breadcrumbs to resource "\' . $to . \'"\';

    return \'\';
}

if (!empty($customParents)) {
    $customParents = is_array($customParents) ? $customParents : array_map(\'trim\', explode(\',\', $customParents));
    $parents = is_array($customParents) ? array_reverse($customParents) : array();
}
if (empty($parents)) {
    $parents = $modx->getParentIds($resource->id, $limit, array(\'context\' => $resource->get(\'context_key\')));
}
if (!empty($showHome)) {
    $parents[] = $siteStart;
}

$ids = array($resource->id);
foreach ($parents as $parent) {
    if (!empty($parent)) {
        $ids[] = $parent;
    }
    if (!empty($from) && $parent == $from) {
        break;
    }
}
$where[\'id:IN\'] = $ids;

if (!empty($exclude)) {
    $where[\'id:NOT IN\'] = array_map(\'trim\', explode(\',\', $exclude));
}

// Fields to select
$resourceColumns = array_keys($modx->getFieldMeta($class));
$select = array($class => implode(\',\', $resourceColumns));

// Add custom parameters
foreach (array(\'where\', \'select\') as $v) {
    if (!empty($scriptProperties[$v])) {
        $tmp = $scriptProperties[$v];
        if (!is_array($tmp)) {
            $tmp = json_decode($tmp, true);
        }
        if (is_array($tmp)) {
            $$v = array_merge($$v, $tmp);
        }
    }
    unset($scriptProperties[$v]);
}
$pdoFetch->addTime(\'Conditions prepared\');

// Default parameters
$default = array(
    \'class\' => $class,
    \'where\' => json_encode($where),
    \'select\' => json_encode($select),
    \'groupby\' => $class . \'.id\',
    \'sortby\' => "find_in_set(`$class`.`id`,\'" . implode(\',\', $ids) . "\')",
    \'sortdir\' => \'\',
    \'return\' => \'data\',
    \'totalVar\' => \'pdocrumbs.total\',
    \'disableConditions\' => true,
);

// Merge all properties and run!
$pdoFetch->addTime(\'Query parameters ready\');
$pdoFetch->setConfig(array_merge($default, $scriptProperties), false);
$rows = $pdoFetch->run();

$output = [];
if (!empty($rows) && is_array($rows)) {
    if (strtolower($direction) == \'ltr\') {
        $rows = array_reverse($rows);
    }

    foreach ($rows as $row) {
        if (!empty($useWeblinkUrl) && $row[\'class_key\'] == \'modWebLink\') {
            $row[\'link\'] = is_numeric(trim($row[\'content\'], \'[]~ \'))
                ? $pdoFetch->makeUrl((int)trim($row[\'content\'], \'[]~ \'), $row)
                : $row[\'content\'];
        } else {
            $row[\'link\'] = $pdoFetch->makeUrl($row[\'id\'], $row);
        }

        $row = array_merge(
            $scriptProperties,
            $row,
            [\'idx\' => $pdoFetch->idx++]
        );
        if (empty($row[\'menutitle\'])) {
            $row[\'menutitle\'] = $row[\'pagetitle\'];
        }

        if (isset($return) && $return === \'data\') {
            $output[] = $row;
            continue;
        }
        if ($row[\'id\'] == $resource->id && empty($showCurrent)) {
            continue;
        } elseif ($row[\'id\'] == $resource->id && !empty($tplCurrent)) {
            $tpl = $tplCurrent;
        } elseif ($row[\'id\'] == $siteStart && !empty($tplHome)) {
            $tpl = $tplHome;
        } else {
            $tpl = $pdoFetch->defineChunk($row);
        }
        $output[] = empty($tpl)
            ? \'<pre>\' . $pdoFetch->getChunk(\'\', $row) . \'</pre>\'
            : $pdoFetch->getChunk($tpl, $row, $fastMode);
    }
}
if (isset($return) && $return === \'data\') {
    return $output;
}

$pdoFetch->addTime(\'Chunks processed\');

if (count($output) == 1 && !empty($hideSingle)) {
    $pdoFetch->addTime(\'The only result was hidden, because the parameter "hideSingle" activated\');
    $output = array();
}

$log = \'\';
if ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {
    $log .= \'<pre class="pdoCrumbsLog">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';
}

if (!empty($toSeparatePlaceholders)) {
    $output[\'log\'] = $log;
    $modx->setPlaceholders($output, $toSeparatePlaceholders);
} else {
    $output = implode($outputSeparator, $output);
    if ($pdoFetch->idx >= $limit && !empty($tplMax) && !empty($output)) {
        $output = ($direction == \'ltr\')
            ? $pdoFetch->getChunk($tplMax, array(), $fastMode) . $output
            : $output . $pdoFetch->getChunk($tplMax, array(), $fastMode);
    }
    $output .= $log;

    if (!empty($tplWrapper) && (!empty($wrapIfEmpty) || !empty($output))) {
        $output = $pdoFetch->getChunk($tplWrapper, array(\'output\' => $output, \'crumbs\' => $output), $fastMode);
    }

    if (!empty($toPlaceholder)) {
        $modx->setPlaceholder($toPlaceholder, $output);
    } else {
        return $output;
    }
}',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'phpthumbof' => 
      array (
        'fields' => 
        array (
          'id' => 1,
          'source' => 0,
          'property_preprocess' => false,
          'name' => 'phpthumbof',
          'description' => 'A custom output filter that generates thumbnails securely with phpThumb.',
          'editor_type' => 0,
          'category' => 0,
          'cache_type' => 0,
          'snippet' => '/**
 * phpThumbOf
 *
 * Copyright 2009-2012 by Shaun McCormick <shaun@modx.com>
 *
 * phpThumbOf is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) any
 * later version.
 *
 * phpThumbOf is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * phpThumbOf; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package phpthumbof
 */
/**
 * A custom output filter for phpThumb
 *
 * @var modX $modx
 * @var array $scriptProperties
 * @var phpThumbOf $phpThumbOf
 * @var string $input
 * @var string|array $options
 *
 * @package phpthumbof
 */
if (empty($modx)) return \'\';
if (!$modx->loadClass(\'modPhpThumb\',$modx->getOption(\'core_path\').\'model/phpthumb/\',true,true)) {
    $modx->log(modX::LOG_LEVEL_ERROR,\'[phpThumbOf] Could not load modPhpThumb class.\');
    return \'\';
}
if (empty($input)) {
    $modx->log(modX::LOG_LEVEL_DEBUG,\'[phpThumbOf] Empty image path passed, aborting.\');
    return \'\';
}
$modelPath = $modx->getOption(\'phpthumbof.core_path\',null,$modx->getOption(\'core_path\').\'components/phpthumbof/\').\'model/\';
require_once $modelPath.\'phpthumbof/phpthumbof.class.php\';
$phpThumbOf = new phpThumbOf($modx,$scriptProperties);

$phpThumbOf->getCacheDirectory();
$phpThumbOf->ensureCacheDirectoryIsWritable();

$thumbnail = $phpThumbOf->createThumbnailObject();
$thumbnail->setInput($input);
$thumbnail->setOptions($options);
$thumbnail->initializeService();
return $thumbnail->render();',
          'locked' => false,
          'properties' => NULL,
          'moduleguid' => '',
          'static' => false,
          'static_file' => '',
          'content' => '/**
 * phpThumbOf
 *
 * Copyright 2009-2012 by Shaun McCormick <shaun@modx.com>
 *
 * phpThumbOf is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) any
 * later version.
 *
 * phpThumbOf is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * phpThumbOf; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package phpthumbof
 */
/**
 * A custom output filter for phpThumb
 *
 * @var modX $modx
 * @var array $scriptProperties
 * @var phpThumbOf $phpThumbOf
 * @var string $input
 * @var string|array $options
 *
 * @package phpthumbof
 */
if (empty($modx)) return \'\';
if (!$modx->loadClass(\'modPhpThumb\',$modx->getOption(\'core_path\').\'model/phpthumb/\',true,true)) {
    $modx->log(modX::LOG_LEVEL_ERROR,\'[phpThumbOf] Could not load modPhpThumb class.\');
    return \'\';
}
if (empty($input)) {
    $modx->log(modX::LOG_LEVEL_DEBUG,\'[phpThumbOf] Empty image path passed, aborting.\');
    return \'\';
}
$modelPath = $modx->getOption(\'phpthumbof.core_path\',null,$modx->getOption(\'core_path\').\'components/phpthumbof/\').\'model/\';
require_once $modelPath.\'phpthumbof/phpthumbof.class.php\';
$phpThumbOf = new phpThumbOf($modx,$scriptProperties);

$phpThumbOf->getCacheDirectory();
$phpThumbOf->ensureCacheDirectoryIsWritable();

$thumbnail = $phpThumbOf->createThumbnailObject();
$thumbnail->setInput($input);
$thumbnail->setOptions($options);
$thumbnail->initializeService();
return $thumbnail->render();',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
        ),
      ),
      'AjaxForm' => 
      array (
        'fields' => 
        array (
          'id' => 9,
          'source' => 1,
          'property_preprocess' => false,
          'name' => 'AjaxForm',
          'description' => '',
          'editor_type' => 0,
          'category' => 9,
          'cache_type' => 0,
          'snippet' => '/** @var array $scriptProperties */
/** @var AjaxForm $AjaxForm */
if (!$modx->loadClass(\'ajaxform\', MODX_CORE_PATH . \'components/ajaxform/model/ajaxform/\', false, true)) {
    return false;
}
$AjaxForm = new AjaxForm($modx, $scriptProperties);

$snippet = $modx->getOption(\'snippet\', $scriptProperties, \'FormIt\', true);
$tpl = $modx->getOption(\'form\', $scriptProperties, \'tpl.AjaxForm.example\', true);
$formSelector = $modx->getOption(\'formSelector\', $scriptProperties, \'ajax_form\', true);
$objectName = $modx->getOption(\'objectName\', $scriptProperties, \'AjaxForm\', true);
$AjaxForm->loadJsCss($objectName);

/** @var pdoTools $pdo */
if (class_exists(\'pdoTools\') && $pdo = $modx->getService(\'pdoTools\')) {
    $content = $pdo->getChunk($tpl, $scriptProperties);
} else {
    $content = $modx->getChunk($tpl, $scriptProperties);
}
if (empty($content)) {
    return $modx->lexicon(\'af_err_chunk_nf\', array(\'name\' => $tpl));
}

// Add selector to tag form
if (preg_match(\'#<form.*?class=(?:"|\\\')(.*?)(?:"|\\\')#i\', $content, $matches)) {
    $classes = explode(\' \', $matches[1]);
    if (!in_array($formSelector, $classes)) {
        $classes[] = $formSelector;
        $classes = preg_replace(
            \'#class=(?:"|\\\')\' . $matches[1] . \'(?:"|\\\')#i\',
            \'class="\' . implode(\' \', $classes) . \'"\',
            $matches[0]
        );
        $content = str_ireplace($matches[0], $classes, $content);
    }
} else {
    $content = str_ireplace(\'<form\', \'<form class="\' . $formSelector . \'"\', $content);
}

// Add method = post
if (preg_match(\'#<form.*?method=(?:"|\\\')(.*?)(?:"|\\\')#i\', $content)) {
    $content = preg_replace(\'#<form(.*?)method=(?:"|\\\')(.*?)(?:"|\\\')#i\', \'<form\\\\1method="post"\', $content);
} else {
    $content = str_ireplace(\'<form\', \'<form method="post"\', $content);
}

// Add action for form processing
$hash = md5(http_build_query($scriptProperties));
$action = \'<input type="hidden" name="af_action" value="\' . $hash . \'" />\';
if ((stripos($content, \'</form>\') !== false)) {
    if (preg_match(\'#<input.*?name=(?:"|\\\')af_action(?:"|\\\').*?>#i\', $content, $matches)) {
        $content = str_ireplace($matches[0], \'\', $content);
    }
    $content = str_ireplace(\'</form>\', "\\n\\t$action\\n</form>", $content);
}

// Save settings to user`s session
$_SESSION[\'AjaxForm\'][$hash] = $scriptProperties;

// Call snippet for preparation of form
$action = !empty($_REQUEST[\'af_action\'])
    ? $_REQUEST[\'af_action\']
    : $hash;

$AjaxForm->process($action, $_REQUEST);

// Return chunk
return $content;',
          'locked' => false,
          'properties' => 
          array (
            'form' => 
            array (
              'name' => 'form',
              'desc' => 'ajaxform_prop_form',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'tpl.AjaxForm.example',
              'lexicon' => 'ajaxform:properties',
              'area' => '',
              'desc_trans' => 'Chunk with form for submit.',
              'area_trans' => '',
            ),
            'snippet' => 
            array (
              'name' => 'snippet',
              'desc' => 'ajaxform_prop_snippet',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'FormIt',
              'lexicon' => 'ajaxform:properties',
              'area' => '',
              'desc_trans' => 'Snippet, that will process specified form.',
              'area_trans' => '',
            ),
            'frontend_css' => 
            array (
              'name' => 'frontend_css',
              'desc' => 'ajaxform_prop_frontend_css',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '[[+assetsUrl]]css/default.css',
              'lexicon' => 'ajaxform:properties',
              'area' => '',
              'desc_trans' => 'File with css styles for frontend.',
              'area_trans' => '',
            ),
            'frontend_js' => 
            array (
              'name' => 'frontend_js',
              'desc' => 'ajaxform_prop_frontend_js',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '[[+assetsUrl]]js/default.js',
              'lexicon' => 'ajaxform:properties',
              'area' => '',
              'desc_trans' => 'File with javascript for frontend.',
              'area_trans' => '',
            ),
            'actionUrl' => 
            array (
              'name' => 'actionUrl',
              'desc' => 'ajaxform_prop_actionUrl',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => '[[+assetsUrl]]action.php',
              'lexicon' => 'ajaxform:properties',
              'area' => '',
              'desc_trans' => 'Connector to handle ajax requests.',
              'area_trans' => '',
            ),
            'formSelector' => 
            array (
              'name' => 'formSelector',
              'desc' => 'ajaxform_prop_formSelector',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'ajax_form',
              'lexicon' => 'ajaxform:properties',
              'area' => '',
              'desc_trans' => 'Еhe name of the CSS class that will be used as a jQuery selector to initialize the form. Default is "ajax_form".',
              'area_trans' => '',
            ),
            'objectName' => 
            array (
              'name' => 'objectName',
              'desc' => 'ajaxform_prop_objectName',
              'type' => 'textfield',
              'options' => 
              array (
              ),
              'value' => 'AjaxForm',
              'lexicon' => 'ajaxform:properties',
              'area' => '',
              'desc_trans' => 'The name of the object to initialize in javascript. Default is "AjaxForm".',
              'area_trans' => '',
            ),
          ),
          'moduleguid' => '',
          'static' => false,
          'static_file' => 'core/components/ajaxform/elements/snippets/snippet.ajaxform.php',
          'content' => '/** @var array $scriptProperties */
/** @var AjaxForm $AjaxForm */
if (!$modx->loadClass(\'ajaxform\', MODX_CORE_PATH . \'components/ajaxform/model/ajaxform/\', false, true)) {
    return false;
}
$AjaxForm = new AjaxForm($modx, $scriptProperties);

$snippet = $modx->getOption(\'snippet\', $scriptProperties, \'FormIt\', true);
$tpl = $modx->getOption(\'form\', $scriptProperties, \'tpl.AjaxForm.example\', true);
$formSelector = $modx->getOption(\'formSelector\', $scriptProperties, \'ajax_form\', true);
$objectName = $modx->getOption(\'objectName\', $scriptProperties, \'AjaxForm\', true);
$AjaxForm->loadJsCss($objectName);

/** @var pdoTools $pdo */
if (class_exists(\'pdoTools\') && $pdo = $modx->getService(\'pdoTools\')) {
    $content = $pdo->getChunk($tpl, $scriptProperties);
} else {
    $content = $modx->getChunk($tpl, $scriptProperties);
}
if (empty($content)) {
    return $modx->lexicon(\'af_err_chunk_nf\', array(\'name\' => $tpl));
}

// Add selector to tag form
if (preg_match(\'#<form.*?class=(?:"|\\\')(.*?)(?:"|\\\')#i\', $content, $matches)) {
    $classes = explode(\' \', $matches[1]);
    if (!in_array($formSelector, $classes)) {
        $classes[] = $formSelector;
        $classes = preg_replace(
            \'#class=(?:"|\\\')\' . $matches[1] . \'(?:"|\\\')#i\',
            \'class="\' . implode(\' \', $classes) . \'"\',
            $matches[0]
        );
        $content = str_ireplace($matches[0], $classes, $content);
    }
} else {
    $content = str_ireplace(\'<form\', \'<form class="\' . $formSelector . \'"\', $content);
}

// Add method = post
if (preg_match(\'#<form.*?method=(?:"|\\\')(.*?)(?:"|\\\')#i\', $content)) {
    $content = preg_replace(\'#<form(.*?)method=(?:"|\\\')(.*?)(?:"|\\\')#i\', \'<form\\\\1method="post"\', $content);
} else {
    $content = str_ireplace(\'<form\', \'<form method="post"\', $content);
}

// Add action for form processing
$hash = md5(http_build_query($scriptProperties));
$action = \'<input type="hidden" name="af_action" value="\' . $hash . \'" />\';
if ((stripos($content, \'</form>\') !== false)) {
    if (preg_match(\'#<input.*?name=(?:"|\\\')af_action(?:"|\\\').*?>#i\', $content, $matches)) {
        $content = str_ireplace($matches[0], \'\', $content);
    }
    $content = str_ireplace(\'</form>\', "\\n\\t$action\\n</form>", $content);
}

// Save settings to user`s session
$_SESSION[\'AjaxForm\'][$hash] = $scriptProperties;

// Call snippet for preparation of form
$action = !empty($_REQUEST[\'af_action\'])
    ? $_REQUEST[\'af_action\']
    : $hash;

$AjaxForm->process($action, $_REQUEST);

// Return chunk
return $content;',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
    'modTemplateVar' => 
    array (
      'nav-contact' => 
      array (
        'fields' => 
        array (
          'id' => 233,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'tag',
          'name' => 'nav-contact',
          'caption' => 'Название пункта меню Контакты',
          'description' => 'Название пункта меню Контакты',
          'editor_type' => 0,
          'category' => 1,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'true',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'text-slide2' => 
      array (
        'fields' => 
        array (
          'id' => 65,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'text',
          'name' => 'text-slide2',
          'caption' => 'Текст в 2 слайде',
          'description' => '',
          'editor_type' => 0,
          'category' => 11,
          'locked' => false,
          'elements' => '',
          'rank' => 3,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'true',
            'minLength' => '',
            'maxLength' => '',
            'regex' => '',
            'regexText' => '',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'image-slide2' => 
      array (
        'fields' => 
        array (
          'id' => 34,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'image-slide2',
          'caption' => 'Картинка 2 слайда',
          'description' => 'Фон слайдера, 1920х750рх',
          'editor_type' => 0,
          'category' => 11,
          'locked' => false,
          'elements' => '',
          'rank' => 2,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'mobile-image-slide2' => 
      array (
        'fields' => 
        array (
          'id' => 36,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'mobile-image-slide2',
          'caption' => 'Картинка 2  мобильного слайда',
          'description' => 'Фон мобильного слайдера, 750х750рх',
          'editor_type' => 0,
          'category' => 11,
          'locked' => false,
          'elements' => '',
          'rank' => 3,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'text-slide1' => 
      array (
        'fields' => 
        array (
          'id' => 64,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'text',
          'name' => 'text-slide1',
          'caption' => 'Текст в 1 слайдере',
          'description' => '',
          'editor_type' => 0,
          'category' => 11,
          'locked' => false,
          'elements' => '',
          'rank' => 1,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'true',
            'minLength' => '',
            'maxLength' => '',
            'regex' => '',
            'regexText' => '',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'image-slide1' => 
      array (
        'fields' => 
        array (
          'id' => 33,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'image-slide1',
          'caption' => 'Картинка 1 слайда',
          'description' => 'Фон слайдера, 1920х750рх',
          'editor_type' => 0,
          'category' => 11,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'mobile-image-slide1' => 
      array (
        'fields' => 
        array (
          'id' => 35,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'mobile-image-slide1',
          'caption' => 'Картинка 1  мобильного слайда',
          'description' => 'Фон мобильного слайдера, 750х750рх',
          'editor_type' => 0,
          'category' => 11,
          'locked' => false,
          'elements' => '',
          'rank' => 1,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'image_product' => 
      array (
        'fields' => 
        array (
          'id' => 9,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'image_product',
          'caption' => '',
          'description' => 'Обложка категории продуктов 590х800рх',
          'editor_type' => 0,
          'category' => 4,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'mobile_image_product' => 
      array (
        'fields' => 
        array (
          'id' => 10,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'mobile_image_product',
          'caption' => '',
          'description' => 'Обложка для мобильной версии категории продуктов 800х500рх',
          'editor_type' => 0,
          'category' => 4,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'product-title' => 
      array (
        'fields' => 
        array (
          'id' => 22,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'tag',
          'name' => 'product-title',
          'caption' => 'Заголовок категории',
          'description' => 'Заголовок категории Product  на главной странице',
          'editor_type' => 0,
          'category' => 4,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'image_innovation' => 
      array (
        'fields' => 
        array (
          'id' => 11,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'image_innovation',
          'caption' => '',
          'description' => 'Обложка категории инновации 590х390рх',
          'editor_type' => 0,
          'category' => 5,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'mobile_image_innovation' => 
      array (
        'fields' => 
        array (
          'id' => 12,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'mobile_image_innovation',
          'caption' => '',
          'description' => 'Обложка для мобильной версии категории инновации 800х500рх',
          'editor_type' => 0,
          'category' => 5,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'rd-innovation-title' => 
      array (
        'fields' => 
        array (
          'id' => 19,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'tag',
          'name' => 'rd-innovation-title',
          'caption' => '',
          'description' => 'Заголовок категории RD innovation на главной странице',
          'editor_type' => 0,
          'category' => 5,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'image_about_gteennovo' => 
      array (
        'fields' => 
        array (
          'id' => 13,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'image_about_gteennovo',
          'caption' => '',
          'description' => 'Обложка категории о компании 590х390рх',
          'editor_type' => 0,
          'category' => 6,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'mobile_image_about_gteennovo' => 
      array (
        'fields' => 
        array (
          'id' => 14,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'mobile_image_about_gteennovo',
          'caption' => '',
          'description' => 'Обложка мобильной версии категории О компании 800х500рх',
          'editor_type' => 0,
          'category' => 6,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'about-title' => 
      array (
        'fields' => 
        array (
          'id' => 16,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'tag',
          'name' => 'about-title',
          'caption' => '',
          'description' => 'Заголовок страницы О компании',
          'editor_type' => 0,
          'category' => 6,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'support-title' => 
      array (
        'fields' => 
        array (
          'id' => 21,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'tag',
          'name' => 'support-title',
          'caption' => 'Заголовок категории',
          'description' => 'Заголовок категории Support&Service на главной странице',
          'editor_type' => 0,
          'category' => 2,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
      'image_support' => 
      array (
        'fields' => 
        array (
          'id' => 8,
          'source' => 1,
          'property_preprocess' => false,
          'type' => 'image',
          'name' => 'image_support',
          'caption' => 'Картинка техподдержки',
          'description' => 'Картинка блока техподдержки 590х390px на главной странице',
          'editor_type' => 0,
          'category' => 2,
          'locked' => false,
          'elements' => '',
          'rank' => 0,
          'display' => 'default',
          'default_text' => '',
          'properties' => 
          array (
          ),
          'input_properties' => 
          array (
            'allowBlank' => 'false',
          ),
          'output_properties' => 
          array (
          ),
          'static' => false,
          'static_file' => '',
          'content' => '',
        ),
        'policies' => 
        array (
          'web' => 
          array (
          ),
        ),
        'source' => 
        array (
          'id' => 1,
          'name' => 'Filesystem',
          'description' => '',
          'class_key' => 'sources.modFileMediaSource',
          'properties' => 
          array (
          ),
          'is_stream' => true,
        ),
      ),
    ),
  ),
);