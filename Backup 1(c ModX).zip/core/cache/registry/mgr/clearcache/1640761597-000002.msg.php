<?php
return array (
  'timestamp' => '2021-12-29 10:06:37',
  'level' => 'INFO',
  'msg' => '-> <strong>0</strong> документов было снято с публикации.',
  'def' => '',
  'file' => '/connectors/index.php',
  'line' => '',
);
