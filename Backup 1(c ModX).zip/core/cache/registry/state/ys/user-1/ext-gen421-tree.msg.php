<?php
return '/Filesystem/assets/img/home';
