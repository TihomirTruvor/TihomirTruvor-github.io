<?php
return 'modx-resource-alias-visible';
