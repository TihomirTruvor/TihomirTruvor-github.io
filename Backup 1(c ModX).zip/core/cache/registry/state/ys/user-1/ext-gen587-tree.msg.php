<?php
return '/Filesystem/assets/img/product';
