<?php
return array (
  'width' => 522,
  'height' => 755,
  'x' => 594,
  'y' => 82,
);
