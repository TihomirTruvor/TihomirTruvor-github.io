<?php
return array (
  'width' => 400,
  'height' => 306,
  'x' => 721,
  'y' => 282,
);
