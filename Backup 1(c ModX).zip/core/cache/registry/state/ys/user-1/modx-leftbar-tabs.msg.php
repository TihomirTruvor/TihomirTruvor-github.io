<?php
return array (
  'collapsed' => false,
  'width' => 339,
);
