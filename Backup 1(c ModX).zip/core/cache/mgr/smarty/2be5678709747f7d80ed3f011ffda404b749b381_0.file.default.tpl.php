<?php
/* Smarty version 3.1.39, created on 2021-12-09 16:56:18
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/tv/renders/properties/default.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b20b0239d5c0_39904441',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2be5678709747f7d80ed3f011ffda404b749b381' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/tv/renders/properties/default.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b20b0239d5c0_39904441 (Smarty_Internal_Template $_smarty_tpl) {
?>&nbsp;<?php }
}
