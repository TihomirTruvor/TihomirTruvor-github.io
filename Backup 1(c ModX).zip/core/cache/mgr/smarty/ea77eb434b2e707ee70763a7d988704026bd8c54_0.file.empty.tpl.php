<?php
/* Smarty version 3.1.39, created on 2021-12-09 16:56:18
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/empty.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b20b022065d9_73991101',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ea77eb434b2e707ee70763a7d988704026bd8c54' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/empty.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b20b022065d9_73991101 (Smarty_Internal_Template $_smarty_tpl) {
?> <?php }
}
