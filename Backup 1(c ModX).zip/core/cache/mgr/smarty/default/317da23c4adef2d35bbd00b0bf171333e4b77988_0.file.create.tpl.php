<?php
/* Smarty version 3.1.39, created on 2021-12-27 14:53:33
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/plugin/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61c9a93d5f54f4_42716498',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '317da23c4adef2d35bbd00b0bf171333e4b77988' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/plugin/create.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61c9a93d5f54f4_42716498 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-plugin-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onPluginFormPrerender']->value;
}
}
