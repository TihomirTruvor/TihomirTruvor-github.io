<?php
/* Smarty version 3.1.39, created on 2021-12-08 16:12:40
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/chunk/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b0af48f39bd4_34349690',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7f2d6eb618ea84f82e0ce0bc24c81597c501ac40' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/chunk/create.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b0af48f39bd4_34349690 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-chunk-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onChunkFormPrerender']->value;
}
}
