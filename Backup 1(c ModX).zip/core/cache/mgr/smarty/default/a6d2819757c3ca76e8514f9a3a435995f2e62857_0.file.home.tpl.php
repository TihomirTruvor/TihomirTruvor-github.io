<?php
/* Smarty version 3.1.39, created on 2021-12-08 17:05:35
  from '/var/www/u1453811/data/www/greennovo.pro/core/components/formit/templates/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b0bbaf661bd4_61498035',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a6d2819757c3ca76e8514f9a3a435995f2e62857' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/core/components/formit/templates/home.tpl',
      1 => 1637762024,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b0bbaf661bd4_61498035 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="formit-panel-home-div"></div><?php }
}
