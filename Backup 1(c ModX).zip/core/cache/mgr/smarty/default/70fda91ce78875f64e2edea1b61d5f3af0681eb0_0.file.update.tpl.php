<?php
/* Smarty version 3.1.39, created on 2021-12-08 16:21:55
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/template/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b0b1730db340_71443143',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '70fda91ce78875f64e2edea1b61d5f3af0681eb0' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/template/update.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b0b1730db340_71443143 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-template-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTempFormPrerender']->value;
}
}
