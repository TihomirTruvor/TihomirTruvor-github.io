<?php
/* Smarty version 3.1.39, created on 2021-12-08 11:59:37
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/chunk/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b073f9b65b69_96157603',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a88192b3958966e58eca22bacb807ecd63a85f1a' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/chunk/update.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b073f9b65b69_96157603 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-chunk-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onChunkFormPrerender']->value;
}
}
