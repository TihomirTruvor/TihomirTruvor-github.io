<?php
/* Smarty version 3.1.39, created on 2021-12-08 15:43:22
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/snippet/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b0a86a93d0e1_50011869',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1a3017f0c0e3e10ff717fc474db429c577d808b7' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/snippet/update.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b0a86a93d0e1_50011869 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-snippet-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onSnipFormPrerender']->value;
}
}
