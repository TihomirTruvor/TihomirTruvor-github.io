<?php
/* Smarty version 3.1.39, created on 2021-12-09 16:56:17
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/tv/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b20b01a99727_93496612',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b52ca1a431bc3203b6dbcc99888e47e81abf006f' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/element/tv/update.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b20b01a99727_93496612 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-tv-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTVFormPrerender']->value;
}
}
