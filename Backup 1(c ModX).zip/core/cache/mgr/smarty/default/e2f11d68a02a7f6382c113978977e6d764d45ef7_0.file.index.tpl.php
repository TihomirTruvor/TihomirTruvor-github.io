<?php
/* Smarty version 3.1.39, created on 2021-12-17 20:15:44
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/workspaces/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61bcc5c08a4947_68878582',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e2f11d68a02a7f6382c113978977e6d764d45ef7' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/workspaces/index.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61bcc5c08a4947_68878582 (Smarty_Internal_Template $_smarty_tpl) {
echo (($tmp = @$_smarty_tpl->tpl_vars['error']->value)===null||$tmp==='' ? '' : $tmp);?>

<div id="modx-panel-workspace-div"></div>
<?php }
}
