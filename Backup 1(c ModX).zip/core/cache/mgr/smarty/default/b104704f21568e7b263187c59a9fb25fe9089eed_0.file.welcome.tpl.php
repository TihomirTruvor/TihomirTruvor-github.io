<?php
/* Smarty version 3.1.39, created on 2021-12-08 18:16:09
  from '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/welcome.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61b0cc3924f182_40203400',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b104704f21568e7b263187c59a9fb25fe9089eed' => 
    array (
      0 => '/var/www/u1453811/data/www/greennovo.pro/manager/templates/default/welcome.tpl',
      1 => 1622181878,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61b0cc3924f182_40203400 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-welcome-div"></div>

<div id="modx-dashboard" class="dashboard">
<?php echo $_smarty_tpl->tpl_vars['dashboard']->value;?>

</div><?php }
}
