<?php  return array (
  'ace' => 
  array (
    'name' => 'ace',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/ace/',
    'assets_path' => '',
  ),
  'ajaxform' => 
  array (
    'name' => 'ajaxform',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/ajaxform/',
    'assets_path' => '',
  ),
  'babel' => 
  array (
    'name' => 'babel',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/babel/',
    'assets_path' => '/var/www/u1453811/data/www/greennovo.pro/assets/components/babel/',
  ),
  'breadcrumbs' => 
  array (
    'name' => 'breadcrumbs',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/breadcrumbs/',
    'assets_path' => '',
  ),
  'core' => 
  array (
    'name' => 'core',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/manager/',
    'assets_path' => '/var/www/u1453811/data/www/greennovo.pro/manager/assets/',
  ),
  'formit' => 
  array (
    'name' => 'formit',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/formit/',
    'assets_path' => '/var/www/u1453811/data/www/greennovo.pro/assets/components/formit/',
  ),
  'pdotools' => 
  array (
    'name' => 'pdotools',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/pdotools/',
    'assets_path' => '',
  ),
  'phpthumbof' => 
  array (
    'name' => 'phpthumbof',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/phpthumbof/',
    'assets_path' => '',
  ),
  'tinymce' => 
  array (
    'name' => 'tinymce',
    'path' => '/var/www/u1453811/data/www/greennovo.pro/core/components/tinymce/',
    'assets_path' => '/var/www/u1453811/data/www/greennovo.pro/assets/components/tinymce/',
  ),
);