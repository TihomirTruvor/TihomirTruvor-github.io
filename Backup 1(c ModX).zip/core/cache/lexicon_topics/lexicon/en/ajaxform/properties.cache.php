<?php  return array (
  'ajaxform_prop_form' => 'Chunk with form for submit.',
  'ajaxform_prop_snippet' => 'Snippet, that will process specified form.',
  'ajaxform_prop_frontend_css' => 'File with css styles for frontend.',
  'ajaxform_prop_frontend_js' => 'File with javascript for frontend.',
  'ajaxform_prop_actionUrl' => 'Connector to handle ajax requests.',
  'ajaxform_prop_formSelector' => 'Еhe name of the CSS class that will be used as a jQuery selector to initialize the form. Default is "ajax_form".',
  'ajaxform_prop_objectName' => 'The name of the object to initialize in javascript. Default is "AjaxForm".',
);