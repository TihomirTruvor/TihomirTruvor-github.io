<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
$xpdo_meta_map['modJSONRPCResource']= array (
  'package' => 'modx',
  'version' => '1.1',
  'extends' => 'modXMLRPCResource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
