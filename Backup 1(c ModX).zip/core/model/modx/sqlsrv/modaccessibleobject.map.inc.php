<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
$xpdo_meta_map['modAccessibleObject']= array (
  'package' => 'modx',
  'version' => '1.1',
  'extends' => 'xPDOObject',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
