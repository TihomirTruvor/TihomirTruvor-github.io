<?php
/**
 * @package modx
 * @subpackage sqlsrv
 */
$xpdo_meta_map['modWebLink']= array (
  'package' => 'modx',
  'version' => '1.1',
  'extends' => 'modResource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
