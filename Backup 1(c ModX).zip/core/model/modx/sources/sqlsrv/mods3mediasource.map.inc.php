<?php
/**
 * @package modx
 * @subpackage sources.sqlsrv
 */
$xpdo_meta_map['modS3MediaSource']= array (
  'package' => 'modx.sources',
  'version' => '1.1',
  'extends' => 'modMediaSource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
